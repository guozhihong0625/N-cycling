library(tidyverse)

phy_raw <- read.csv(
  "table-l2-relabun.csv",
  header = TRUE,
  check.names = FALSE
)


# 删除空列
phy_raw <- phy_raw[, !is.na(colnames(phy_raw))]


# 查看结构
dim(phy_raw)

head(phy_raw[,1:5])


################################################
# 正确转换
################################################


# 第一列：门名称
phy_name <- phy_raw[,1]


# 后面全部是丰度
phy <- phy_raw[,-1]


# 行列转换
phy <- t(phy)


# 转data.frame
phy <- as.data.frame(phy)


# 设置门名称
colnames(phy) <- phy_name


# 设置样本名
rownames(phy) <- colnames(phy_raw)[-1]


# 全部转数字
phy[] <- lapply(
  phy,
  as.numeric
)


################################################
# 检查
################################################

dim(phy)

head(colnames(phy))

head(rownames(phy))


















############################################################
# Phylum name cleaning
############################################################

clean_phylum <- function(x){
  
  x <- gsub(
    "^k__Bacteria;p__",
    "",
    x
  )
  
  x <- gsub(
    "^k__Archaea;p__",
    "",
    x
  )
  
  x <- gsub(
    "^k__Bacteria;__",
    "Unclassified_Bacteria",
    x
  )
  
  x <- gsub(
    "^k__Archaea;__",
    "Unclassified_Archaea",
    x
  )
  
  x <- gsub(
    "\\[|\\]",
    "",
    x
  )
  
  return(x)
  
}


colnames(phy) <- clean_phylum(colnames(phy))


# 去除全0门

phy <- phy[,colSums(phy)>0]


# 平均丰度

mean_abundance <- colMeans(
  phy,
  na.rm = TRUE
)


head(
  sort(
    mean_abundance,
    decreasing = TRUE
  ),
  20
)










library(tidyverse)


top15 <- names(
  sort(
    mean_abundance,
    decreasing = TRUE
  )[1:15]
)


composition <- phy[,top15]


composition$Others <-
  1-rowSums(composition)



composition_long <- composition %>%
  
  rownames_to_column(
    "SampleID"
  ) %>%
  
  pivot_longer(
    cols=-SampleID,
    names_to="Phylum",
    values_to="Abundance"
  )



p1 <- ggplot(
  composition_long,
  aes(
    x=SampleID,
    y=Abundance,
    fill=Phylum
  )
)+
  
  geom_bar(
    stat="identity"
  )+
  
  theme_bw()+
  
  theme(
    axis.text.x=
      element_text(
        angle=90,
        size=6
      ),
    legend.position="top"
  )+
  
  labs(
    x=NULL,
    y="Relative abundance"
  )



ggsave(
  "Phylum_Top15_composition_all.pdf",
  p1,
  width=14,
  height=7
)