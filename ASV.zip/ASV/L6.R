############################################################
# 16S alpha and beta diversity analysis
# Aligned with metagenomic sampling campaigns
#
# Input:
# rarefied_table(1).csv
#
# Output:
# Shannon / Simpson / Pielou
# Bray-Curtis PCoA
# PERMANOVA
#
############################################################


library(tidyverse)
library(vegan)
library(ggplot2)
library(openxlsx)
library(ggrepel)


############################################################
# 1. Read ASV rarefied table
############################################################


file <- "rarefied_table.csv"


asv <- read.csv(
  file,
  check.names = FALSE
)


# 第一列为ASV ID
rownames(asv) <- asv$ASV_ID

asv$ASV_ID <- NULL


# 转置
# 变成：
# Sample × ASV

asv <- t(asv)

asv <- as.data.frame(asv)


# 全部转numeric

asv[] <- lapply(
  asv,
  as.numeric
)


############################################################
# 2. Construct metadata
############################################################


metadata <- data.frame(
  
  SampleID = rownames(asv),
  
  stringsAsFactors = FALSE
  
)



# 年份

metadata$Year_code <- substr(
  metadata$SampleID,
  1,
  2
)


metadata$Month <- substr(
  metadata$SampleID,
  3,
  4
)


metadata$River_code <- substr(
  metadata$SampleID,
  5,
  5
)


metadata$Position_code <- substr(
  metadata$SampleID,
  6,
  6
)



metadata$Year <- paste0(
  "20",
  metadata$Year_code
)



############################################################
# 3. Keep campaigns consistent with metagenome
############################################################


target_campaign <- c(
  
  "1511",
  "1603",
  "1609",
  "1809",
  "1812",
  "1903"
  
)


metadata$Campaign_code <- paste0(
  metadata$Year_code,
  metadata$Month
)


keep <- metadata$Campaign_code %in%
  target_campaign



metadata <- metadata[keep,]


asv <- asv[
  metadata$SampleID,
]



############################################################
# 4. Define groups
############################################################


metadata$Campaign <- case_when(
  
  metadata$Campaign_code=="1511" ~
    "2015-11",
  
  metadata$Campaign_code=="1603" ~
    "2016-03",
  
  metadata$Campaign_code=="1609" ~
    "2016-09",
  
  metadata$Campaign_code=="1809" ~
    "2018-09",
  
  metadata$Campaign_code=="1812" ~
    "2018-12",
  
  metadata$Campaign_code=="1903" ~
    "2019-03"
  
)



metadata$River <- case_when(
  
  metadata$River_code=="G" ~
    "Tonghui",
  
  metadata$River_code=="Q" ~
    "Qing",
  
  TRUE ~
    "Unknown"
  
)



metadata$Position <- case_when(
  
  metadata$Position_code=="U" ~
    "Upstream",
  
  metadata$Position_code=="E" ~
    "Outfall",
  
  metadata$Position_code=="D" ~
    "Downstream",
  
  TRUE ~
    "Unknown"
  
)



metadata$Campaign <- factor(
  
  metadata$Campaign,
  
  levels=c(
    
    "2015-11",
    "2016-03",
    "2016-09",
    "2018-09",
    "2018-12",
    "2019-03"
    
  )
  
)



metadata$River <- factor(
  
  metadata$River,
  
  levels=c(
    "Tonghui",
    "Qing"
  )
  
)



metadata$Position <- factor(
  
  metadata$Position,
  
  levels=c(
    "Upstream",
    "Outfall",
    "Downstream"
  )
  
)



rownames(metadata) <-
  metadata$SampleID



############################################################
# 5. Check sample number
############################################################


cat(
  "Samples retained:",
  nrow(metadata),
  "\n"
)


print(
  table(
    metadata$Campaign,
    metadata$River
  )
)



############################################################
# 6. Alpha diversity
############################################################


# Shannon

alpha <- data.frame(
  
  SampleID =
    rownames(asv)
  
)



alpha$Shannon <- diversity(
  
  asv,
  
  index="shannon"
  
)



# Simpson

alpha$Simpson <- diversity(
  
  asv,
  
  index="simpson"
  
)



# Richness

alpha$Richness <- specnumber(
  asv
)



# Pielou

alpha$Pielou <-
  
  alpha$Shannon /
  log(alpha$Richness)



alpha <- left_join(
  
  alpha,
  
  metadata,
  
  by="SampleID"
  
)



write.xlsx(
  
  alpha,
  
  "Alpha_diversity_results.xlsx"
  
)


############################################################
# 7. Improved Shannon diversity plot
############################################################


p1 <- ggplot(
  
  alpha,
  
  aes(
    
    x=Campaign,
    
    y=Shannon,
    
    fill=River
    
  )
  
)+
  
  
  # 箱线图
  
  geom_boxplot(
    
    width=0.65,
    
    alpha=0.35,
    
    outlier.shape = NA,
    
    position =
      position_dodge(
        width=0.75
      )
    
  )+
  
  
  # 样本点
  
  geom_jitter(
    
    aes(
      
      color=Position
      
    ),
    
    size=2.2,
    
    alpha=0.85,
    
    width=0.12,
    
    height=0
    
  )+
  
  
  # 主题
  
  theme_bw()+
  
  
  theme(
    
    panel.grid.major =
      element_blank(),
    
    panel.grid.minor =
      element_blank(),
    
    axis.text.x =
      element_text(
        
        angle=45,
        
        hjust=1,
        
        size=11
        
      ),
    
    axis.text.y =
      element_text(
        
        size=11
        
      ),
    
    axis.title =
      element_text(
        
        size=13,
        
        face="bold"
        
      ),
    
    legend.position="top",
    
    legend.title =
      element_blank()
    
  )+
  
  
  labs(
    
    x=NULL,
    
    y="Shannon diversity index"
    
  )



ggsave(
  
  "Fig_alpha_Shannon_improved.pdf",
  
  p1,
  
  width=9,
  
  height=6,
  
  dpi=600
  
)

############################################################
# 8. Bray-Curtis distance
############################################################


bray <- vegdist(
  
  asv,
  
  method="bray"
  
)



############################################################
# 9. PCoA
############################################################


pcoa <- cmdscale(
  
  bray,
  
  eig=TRUE,
  
  k=2
  
)



pcoa_df <- data.frame(
  
  SampleID =
    rownames(pcoa$points),
  
  PCoA1 =
    pcoa$points[,1],
  
  PCoA2 =
    pcoa$points[,2]
  
)



pcoa_df <- left_join(
  
  pcoa_df,
  
  metadata,
  
  by="SampleID"
  
)



var1 <- round(
  
  pcoa$eig[1]/
    sum(pcoa$eig[pcoa$eig>0])*100,
  
  1
  
)



var2 <- round(
  
  pcoa$eig[2]/
    sum(pcoa$eig[pcoa$eig>0])*100,
  
  1
  
)



############################################################
# 10. PCoA plot
############################################################


p2 <- ggplot(
  
  pcoa_df,
  
  aes(
    
    PCoA1,
    
    PCoA2,
    
    color=Campaign,
    
    shape=River
    
  )
  
)+
  
  
  geom_point(
    
    size=3
    
  )+
  
  
  theme_bw()+
  
  
  theme(
    
    panel.grid=element_blank(),
    
    legend.position="top"
    
  )+
  
  
  labs(
    
    x=paste0(
      "PCoA1 (",
      var1,
      "%)"
    ),
    
    y=paste0(
      "PCoA2 (",
      var2,
      "%)"
    )
    
  )



ggsave(
  
  "Fig_beta_PCoA.pdf",
  
  p2,
  
  width=6,
  
  height=6
  
)



############################################################
# 11. PERMANOVA
############################################################
library(vegan)
###############################################
# PERMANOVA - marginal effect of each factor
############################################################

set.seed(123)

permanova_margin <- adonis2(
  
  bray ~
    Campaign +
    River +
    Position,
  
  data = metadata,
  
  permutations = 9999,
  
  by = "margin"
)

print(permanova_margin)

write.xlsx(
  as.data.frame(permanova_margin),
  "PERMANOVA_results.xlsx",
  rowNames = TRUE
)

############################################################
# Multivariate dispersion tests
############################################################

set.seed(123)


# Campaign
bd_campaign <- betadisper(
  bray,
  metadata$Campaign
)

disp_campaign <- permutest(
  bd_campaign,
  permutations = 9999
)

print(disp_campaign)


# River
bd_river <- betadisper(
  bray,
  metadata$River
)

disp_river <- permutest(
  bd_river,
  permutations = 9999
)

print(disp_river)


# Position
bd_position <- betadisper(
  bray,
  metadata$Position
)

disp_position <- permutest(
  bd_position,
  permutations = 9999
)

print(disp_position)

############################################################
# Define pre- and post-upgrade periods
############################################################

alpha <- alpha %>%
  mutate(
    
    Period = case_when(
      
      River == "Tonghui" & Campaign %in% c(
        "2015-11",
        "2016-03",
        "2016-09"
      ) ~ "Tonghui_Pre",
      
      River == "Tonghui" & Campaign %in% c(
        "2018-09",
        "2018-12",
        "2019-03"
      ) ~ "Tonghui_Post",
      
      River == "Qing" ~ "Qing_Control",
      
      TRUE ~ NA_character_
    )
    
  )


alpha$Period <- factor(
  alpha$Period,
  levels=c(
    "Tonghui_Pre",
    "Tonghui_Post",
    "Qing_Control"
  )
)
alpha_summary <- alpha %>%
  
  group_by(
    River,
    Period
  ) %>%
  
  summarise(
    
    n = n(),
    
    Mean = mean(
      Shannon,
      na.rm = TRUE
    ),
    
    SD = sd(
      Shannon,
      na.rm = TRUE
    ),
    
    Median = median(
      Shannon,
      na.rm = TRUE
    ),
    
    IQR = IQR(
      Shannon,
      na.rm = TRUE
    ),
    
    .groups = "drop"
  )

print(alpha_summary)







alpha <- alpha %>%
  mutate(
    Stage = case_when(
      
      Campaign %in% c(
        "2015-11",
        "2016-03",
        "2016-09"
      ) ~ "Before",
      
      Campaign %in% c(
        "2018-09",
        "2018-12",
        "2019-03"
      ) ~ "After"
      
    )
  )

model <- lm(
  Shannon ~ River * Stage,
  data = alpha
)

anova(model)
summary(model)





############################################################
# END
############################################################


cat("\nAnalysis completed!\n")











































############################################################
# Supplementary Tables generation
############################################################

library(vegan)
library(dplyr)
library(openxlsx)

############################################################
# Create Stage variable for beta diversity
############################################################


metadata <- metadata %>%
  
  mutate(
    
    Stage = case_when(
      
      Campaign %in% c(
        "2015-11",
        "2016-03",
        "2016-09"
      ) ~ "Before",
      
      Campaign %in% c(
        "2018-09",
        "2018-12",
        "2019-03"
      ) ~ "After"
      
    )
    
  )



metadata$Stage <- factor(
  
  metadata$Stage,
  
  levels=c(
    "Before",
    "After"
  )
  
)

############################################################
# Table S11a
# PERMANOVA
############################################################


set.seed(123)


permanova <- adonis2(
  
  bray ~
    
    River * Stage +
    
    Position,
  
  data = metadata,
  
  permutations = 9999,
  
  by = "margin"
  
)



permanova_table <-
  
  as.data.frame(
    permanova
  )


permanova_table


write.xlsx(
  
  permanova_table,
  
  "Table_S11a_PERMANOVA.xlsx",
  
  rowNames = TRUE
  
)

############################################################
# Table S11b
# Multivariate dispersion
############################################################


disp_river <- betadisper(
  
  bray,
  
  metadata$River
  
)


disp_river_test <- anova(
  
  disp_river
  
)


disp_river_table <-
  
  as.data.frame(
    
    disp_river_test
    
  )



disp_river_table


disp_stage <- betadisper(
  
  bray,
  
  metadata$Stage
  
)


disp_stage_test <- anova(
  
  disp_stage
  
)


disp_stage_table <-
  
  as.data.frame(
    
    disp_stage_test
    
  )

dispersion_table <-
  
  list(
    
    River = disp_river_table,
    
    Stage = disp_stage_table
    
  )



write.xlsx(
  
  dispersion_table,
  
  "Table_S11b_Multivariate_dispersion.xlsx"
  
)

############################################################
# Create Period
############################################################


alpha <- alpha %>%
  
  mutate(
    
    Period = case_when(
      
      River=="Tonghui" &
        Campaign %in% c(
          "2015-11",
          "2016-03",
          "2016-09"
        ) ~ "Tonghui_Pre",
      
      River=="Tonghui" &
        Campaign %in% c(
          "2018-09",
          "2018-12",
          "2019-03"
        ) ~ "Tonghui_Post",
      
      River=="Qing" ~ "Qing_Control"
      
    )
    
  )


############################################################
# Table S12a
# Shannon descriptive statistics
############################################################


shannon_summary <-
  
  alpha %>%
  
  group_by(
    
    River,
    
    Period
    
  )%>%
  
  summarise(
    
    n=n(),
    
    Mean_Shannon =
      mean(
        Shannon,
        na.rm=TRUE
      ),
    
    SD =
      sd(
        Shannon,
        na.rm=TRUE
      ),
    
    Median =
      median(
        Shannon,
        na.rm=TRUE
      ),
    
    IQR =
      IQR(
        Shannon,
        na.rm=TRUE
      ),
    
    .groups="drop"
    
  )



shannon_summary


write.xlsx(
  
  shannon_summary,
  
  "Table_S12a_Shannon_summary.xlsx"
  
)


############################################################
# Table S12b
# Difference-in-differences model
############################################################


alpha_DID <- alpha %>%
  
  mutate(
    
    Stage = case_when(
      
      Campaign %in% c(
        "2015-11",
        "2016-03",
        "2016-09"
      ) ~ "Before",
      
      Campaign %in% c(
        "2018-09",
        "2018-12",
        "2019-03"
      ) ~ "After"
      
    )
    
  )


alpha_DID$Stage <-
  
  factor(
    
    alpha_DID$Stage,
    
    levels=c(
      "Before",
      "After"
    )
    
  )



DID_model <-
  
  lm(
    
    Shannon ~
      
      River * Stage,
    
    data = alpha_DID
    
  )



DID_anova <-
  
  anova(
    
    DID_model
    
  )



DID_anova


write.xlsx(
  
  as.data.frame(DID_anova),
  
  "Table_S12b_DID_Shannon.xlsx",
  
  rowNames=TRUE
  
)