# ================================================================
# N-cycling genes spatiotemporal bar plots - 修正版（自动识别数据方向）
#
# 适用于两种 Excel 数据结构：
#   A. 行 = Gene，列 = SampleID
#   B. 行 = SampleID，列 = Gene   <- 你的 DATA.xlsx 很可能是这种
#
# 核心修复：不再强制把第1列当 Gene，而是自动判断“样品在行还是在列”。
# ================================================================

rm(list = ls())
graphics.off()

# ---------------------------
# 0. 用户设置
# ---------------------------
input_file <- "C:/Users/guo zhihong/OneDrive/桌面/JECE-D-26-10893-reviews/修改痕迹/DATA.xlsx"
excel_sheet <- "all_genes (use)"

output_dir <- file.path(dirname(input_file), "N_cycling_gene_spatiotemporal_barplots")
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

# 样品编号中的河流代码
river_map <- c(
  "G" = "Tonghui River",
  "Q" = "Qing River"
)

# 六次采样时间
campaign_map <- c(
  "1511" = "2015-11",
  "1603" = "2016-03",
  "1609" = "2016-09",
  "1809" = "2018-09",
  "1812" = "2018-12",
  "1903" = "2019-03"
)

site_levels <- c("U0", "U1", "U2", "E", "D1", "D2", "D3")

position_cols <- c(
  "Upstream"   = "#3C5488FF",
  "Outfall"    = "#E64B35FF",
  "Downstream" = "#00A087FF"
)

font_family <- "Times New Roman"
png_dpi <- 900

# ---------------------------
# 1. 安装/加载包
# ---------------------------
packages <- c(
  "dplyr", "tidyr", "stringr", "ggplot2",
  "readxl", "openxlsx", "scales"
)

new_packages <- packages[!(packages %in% installed.packages()[, "Package"])]
if (length(new_packages) > 0) {
  install.packages(new_packages, dependencies = TRUE)
}
invisible(lapply(packages, library, character.only = TRUE))

# ---------------------------
# 2. 基本函数
# ---------------------------
# 样品编号格式：1511GD1 / 1603QE / 1809GU0 等
sample_pattern <- "^(1511|1603|1609|1809|1812|1903)[GQ](U[0-9]+|D[0-9]+|E)$"

is_sample_id <- function(x) {
  x <- trimws(as.character(x))
  grepl(sample_pattern, x, ignore.case = FALSE)
}

# 论文10个目标基因
gene_order <- c(
  "gdh", "glnA", "narG", "nasA", "nirB",
  "nirS", "norB", "nosZ", "nxrB", "nifH"
)

normalize_gene_name <- function(x) {
  x <- trimws(as.character(x))
  x <- gsub("\\\\_", "_", x)
  x[x == "gdh_K00262"] <- "gdh"
  x
}

# ---------------------------
# 3. 读取 Excel
# ---------------------------
sheets <- readxl::excel_sheets(input_file)
sheet_trim <- trimws(sheets)
target_trim <- trimws(excel_sheet)

if (!(target_trim %in% sheet_trim)) {
  stop(
    paste0(
      "未找到工作表：", excel_sheet,
      "\n当前 DATA.xlsx 中的工作表有：\n",
      paste0("  - ", sheets, collapse = "\n")
    )
  )
}

sheet_use <- sheets[match(target_trim, sheet_trim)]
message("正在读取 Excel 工作表：'", sheet_use, "'")

raw_dat <- readxl::read_excel(
  input_file,
  sheet = sheet_use,
  .name_repair = "minimal"
)
raw_dat <- as.data.frame(raw_dat, check.names = FALSE)

# 清理列名
names(raw_dat) <- trimws(names(raw_dat))

cat("\n原始数据维度：", nrow(raw_dat), " 行 × ", ncol(raw_dat), " 列\n")
cat("前10个列名：\n")
print(head(names(raw_dat), 10))

# ---------------------------
# 4. 自动判断数据方向
# ---------------------------
# 4.1 检查“列名中有多少样品编号”
col_is_sample <- is_sample_id(names(raw_dat))
n_sample_cols <- sum(col_is_sample)

# 4.2 检查“哪一列的单元格中有大量样品编号”
sample_score <- sapply(raw_dat, function(z) {
  if (is.list(z)) return(0)
  mean(is_sample_id(z), na.rm = TRUE)
})

best_sample_col <- names(raw_dat)[which.max(sample_score)]
best_sample_score <- max(sample_score, na.rm = TRUE)

# 4.3 检查“哪一列的单元格中包含最多目标基因名”
gene_score <- sapply(raw_dat, function(z) {
  z2 <- normalize_gene_name(z)
  sum(z2 %in% gene_order, na.rm = TRUE)
})

best_gene_col <- names(raw_dat)[which.max(gene_score)]
best_gene_score <- max(gene_score, na.rm = TRUE)

cat("\n自动识别结果：\n")
cat("列名中识别到样品编号数：", n_sample_cols, "\n")
cat("最像 SampleID 的数据列：", best_sample_col,
    "；样品编号比例 = ", round(best_sample_score, 3), "\n", sep = "")
cat("最像 Gene 的数据列：", best_gene_col,
    "；匹配到目标基因数 = ", best_gene_score, "\n", sep = "")

# 判定规则：
# - 若列名中存在 >= 5 个样品编号 => 行=gene，列=sample
# - 否则若某一列中 >= 50% 为样品编号 => 行=sample，列=gene
if (n_sample_cols >= 5) {
  data_orientation <- "genes_in_rows"
} else if (best_sample_score >= 0.50) {
  data_orientation <- "samples_in_rows"
} else {
  stop(
    paste0(
      "无法自动识别数据方向。\n",
      "请检查 Excel：样品编号应类似 1511GD1、1603QE、1809GU0。\n",
      "当前列名中的样品编号数 = ", n_sample_cols,
      "；最像 SampleID 的列 = ", best_sample_col,
      "，匹配比例 = ", round(best_sample_score, 3)
    )
  )
}

message("判定的数据结构：", data_orientation)

# ---------------------------
# 5. 转成长表：Gene / SampleID / Abundance
# ---------------------------
if (data_orientation == "genes_in_rows") {
  
  # 找包含目标基因最多的列作为 Gene 列
  gene_col <- best_gene_col
  
  dat2 <- raw_dat
  dat2[[gene_col]] <- normalize_gene_name(dat2[[gene_col]])
  
  # 只保留样品列，避免把非样品列误当 SampleID
  sample_cols <- names(dat2)[is_sample_id(names(dat2))]
  
  if (length(sample_cols) == 0) {
    stop("已判定为 Gene×Sample 结构，但没有找到合法样品列。")
  }
  
  missing_genes <- setdiff(gene_order, unique(dat2[[gene_col]]))
  if (length(missing_genes) > 0) {
    warning("以下目标基因未找到：", paste(missing_genes, collapse = ", "))
  }
  
  gene_long <- dat2 %>%
    dplyr::filter(.data[[gene_col]] %in% gene_order) %>%
    dplyr::select(all_of(gene_col), all_of(sample_cols)) %>%
    tidyr::pivot_longer(
      cols = all_of(sample_cols),
      names_to = "SampleID",
      values_to = "Abundance"
    ) %>%
    dplyr::rename(Gene = all_of(gene_col))
  
} else {
  
  # 行 = SampleID，列 = Gene
  sample_col <- best_sample_col
  dat2 <- raw_dat
  dat2[[sample_col]] <- trimws(as.character(dat2[[sample_col]]))
  
  # 基因列名标准化
  old_names <- names(dat2)
  new_names <- normalize_gene_name(old_names)
  names(dat2) <- new_names
  
  # 若重命名后出现重复列名，仅保留原始目标列；先检查
  if (anyDuplicated(names(dat2)) > 0) {
    dup_names <- unique(names(dat2)[duplicated(names(dat2))])
    stop(
      paste0(
        "基因列名标准化后出现重复列名：",
        paste(dup_names, collapse = ", "),
        "。请检查工作表中的基因列。"
      )
    )
  }
  
  # sample_col 名称可能也被 normalize 过，因此重新定位
  sample_col2 <- names(dat2)[match(sample_col, old_names)]
  if (is.na(sample_col2)) sample_col2 <- sample_col
  
  # 只保留合法样品行
  dat2 <- dat2 %>%
    dplyr::filter(is_sample_id(.data[[sample_col2]]))
  
  available_genes <- intersect(gene_order, names(dat2))
  missing_genes <- setdiff(gene_order, available_genes)
  if (length(missing_genes) > 0) {
    warning("以下目标基因列未找到：", paste(missing_genes, collapse = ", "))
  }
  
  if (length(available_genes) == 0) {
    stop(
      paste0(
        "识别到 Sample×Gene 结构，但没有找到10个目标基因列。\n",
        "请检查列名。目标基因应包含：",
        paste(gene_order, collapse = ", ")
      )
    )
  }
  
  gene_long <- dat2 %>%
    dplyr::select(SampleID = all_of(sample_col2), all_of(available_genes)) %>%
    tidyr::pivot_longer(
      cols = -SampleID,
      names_to = "Gene",
      values_to = "Abundance"
    )
}

# 转数值并清理
gene_long <- gene_long %>%
  mutate(
    SampleID = trimws(as.character(SampleID)),
    Gene = normalize_gene_name(Gene),
    Abundance = suppressWarnings(as.numeric(Abundance))
  ) %>%
  filter(Gene %in% gene_order)

cat("\n转换成长表后：\n")
cat("识别样品数：", dplyr::n_distinct(gene_long$SampleID), "\n")
cat("识别目标基因数：", dplyr::n_distinct(gene_long$Gene), "\n")
cat("目标基因：", paste(sort(unique(gene_long$Gene)), collapse = ", "), "\n")

# ---------------------------
# 6. 解析 SampleID
# ---------------------------
gene_long <- gene_long %>%
  mutate(
    CampaignCode = stringr::str_sub(SampleID, 1, 4),
    RiverCode = stringr::str_sub(SampleID, 5, 5),
    Site = stringr::str_sub(SampleID, 6),
    Position = case_when(
      stringr::str_detect(Site, "^U") ~ "Upstream",
      Site == "E" ~ "Outfall",
      stringr::str_detect(Site, "^D") ~ "Downstream",
      TRUE ~ NA_character_
    ),
    River = unname(river_map[RiverCode]),
    Campaign = unname(campaign_map[CampaignCode]),
    Period_G = case_when(
      RiverCode == "G" & CampaignCode %in% c("1511", "1603", "1609") ~ "Pre-upgrade",
      RiverCode == "G" & CampaignCode %in% c("1809", "1812", "1903") ~ "Post-upgrade",
      TRUE ~ NA_character_
    )
  )

bad_sample <- gene_long %>%
  filter(is.na(River) | is.na(Campaign) | is.na(Position)) %>%
  distinct(SampleID, RiverCode, Site, River, Campaign, Position)

if (nrow(bad_sample) > 0) {
  cat("\n以下样品编号无法解析：\n")
  print(bad_sample, n = Inf)
  stop("存在无法解析的样品编号。请检查 SampleID 编码格式。")
}

# 因子排序
gene_long <- gene_long %>%
  mutate(
    Gene = factor(Gene, levels = gene_order),
    Campaign = factor(Campaign, levels = unname(campaign_map)),
    River = factor(River, levels = unname(river_map)),
    Site = factor(Site, levels = site_levels),
    Position = factor(Position, levels = c("Upstream", "Outfall", "Downstream"))
  )

# ---------------------------
# 7. metadata 与汇总
# ---------------------------
sample_metadata <- gene_long %>%
  distinct(SampleID, CampaignCode, Campaign, RiverCode, River, Site, Position, Period_G) %>%
  arrange(River, Campaign, Site)

cat("\n==============================================\n")
cat("成功解析样品数：", nrow(sample_metadata), "\n")
cat("成功解析基因数：", dplyr::n_distinct(gene_long$Gene), "\n")
cat("==============================================\n")
print(table(sample_metadata$River, sample_metadata$Campaign, useNA = "ifany"))

summary_position <- gene_long %>%
  filter(!is.na(Abundance)) %>%
  group_by(Gene, River, Campaign, Position) %>%
  summarise(
    n = n(),
    Mean = mean(Abundance, na.rm = TRUE),
    SD = ifelse(n() > 1, sd(Abundance, na.rm = TRUE), NA_real_),
    SE = ifelse(n() > 1, sd(Abundance, na.rm = TRUE) / sqrt(n()), NA_real_),
    .groups = "drop"
  )

# ---------------------------
# 8. 导出整理数据
# ---------------------------
openxlsx::write.xlsx(
  list(
    Sample_metadata = sample_metadata,
    Long_data = gene_long,
    Position_summary = summary_position
  ),
  file = file.path(output_dir, "Spatiotemporal_gene_plot_data.xlsx"),
  overwrite = TRUE
)

# ---------------------------
# 9. 绘图主题
# ---------------------------
theme_sci <- theme_bw(base_size = 11, base_family = font_family) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(linewidth = 0.6, colour = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, colour = "black"),
    axis.text.y = element_text(colour = "black"),
    axis.title = element_text(colour = "black"),
    strip.background = element_rect(fill = "white", colour = "black", linewidth = 0.5),
    strip.text = element_text(face = "bold", colour = "black"),
    legend.position = "top",
    legend.title = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.caption = element_text(hjust = 0, size = 9)
  )

gene_labels <- c(
  "gdh"  = "italic(gdh)",
  "glnA" = "italic(glnA)",
  "narG" = "italic(narG)",
  "nasA" = "italic(nasA)",
  "nirB" = "italic(nirB)",
  "nirS" = "italic(nirS)",
  "norB" = "italic(norB)",
  "nosZ" = "italic(nosZ)",
  "nxrB" = "italic(nxrB)",
  "nifH" = "italic(nifH)"
)
gene_labeller <- as_labeller(gene_labels, label_parsed)

# ---------------------------
# 10. 主图：每条河 10基因综合图
# ---------------------------
plot_position_summary <- function(river_name) {
  ds <- summary_position %>% filter(River == river_name)
  dl <- gene_long %>% filter(River == river_name)
  
  p <- ggplot(ds, aes(x = Campaign, y = Mean, fill = Position)) +
    geom_col(
      position = position_dodge(width = 0.80),
      width = 0.72,
      colour = "black",
      linewidth = 0.22
    ) +
    geom_errorbar(
      data = ds %>% filter(n > 1, !is.na(SE)),
      aes(ymin = pmax(Mean - SE, 0), ymax = Mean + SE),
      position = position_dodge(width = 0.80),
      width = 0.18,
      linewidth = 0.35
    ) +
    geom_point(
      data = dl,
      aes(x = Campaign, y = Abundance, fill = Position, group = Position),
      inherit.aes = FALSE,
      shape = 21,
      colour = "black",
      stroke = 0.22,
      size = 1.6,
      alpha = 0.72,
      position = position_jitterdodge(
        jitter.width = 0.08,
        jitter.height = 0,
        dodge.width = 0.80,
        seed = 119
      )
    ) +
    facet_wrap(~ Gene, ncol = 2, scales = "free_y", labeller = gene_labeller) +
    scale_fill_manual(values = position_cols, drop = FALSE) +
    scale_x_discrete(drop = FALSE) +
    scale_y_continuous(
      expand = expansion(mult = c(0, 0.10)),
      labels = scales::label_number(accuracy = 0.001)
    ) +
    labs(
      x = "Sampling campaign",
      y = "Normalized gene abundance\n(copies per 16S rRNA gene copy)",
      title = river_name
    ) +
    theme_sci
  
  if (river_name == unname(river_map["G"])) {
    p <- p +
      geom_vline(xintercept = 3.5, linetype = "dashed", linewidth = 0.45) +
      labs(caption = "Dashed line separates sampling campaigns before and after completion of the Gaobeidian WWTP upgrade in April 2017.")
  }
  
  p
}

for (rv in unname(river_map)) {
  if (sum(gene_long$River == rv, na.rm = TRUE) == 0) next
  
  p_river <- plot_position_summary(rv)
  safe_name <- gsub(" ", "_", rv)
  
  ggsave(
    filename = file.path(output_dir, paste0("Main_10genes_", safe_name, ".png")),
    plot = p_river,
    width = 9.5,
    height = 13.5,
    units = "in",
    dpi = png_dpi,
    bg = "white"
  )
  
  ggsave(
    filename = file.path(output_dir, paste0("Main_10genes_", safe_name, ".pdf")),
    plot = p_river,
    width = 9.5,
    height = 13.5,
    units = "in",
    device = cairo_pdf
  )
}

# ---------------------------
# 11. 详细时空图：每个基因一张，展示精确站点
# ---------------------------
detail_dir <- file.path(output_dir, "Site_level_each_gene")
if (!dir.exists(detail_dir)) dir.create(detail_dir, recursive = TRUE)

for (g in gene_order) {
  dg <- gene_long %>% filter(Gene == g)
  if (nrow(dg) == 0) next
  
  p_detail <- ggplot(dg, aes(x = Site, y = Abundance, fill = Position)) +
    geom_col(width = 0.72, colour = "black", linewidth = 0.22, na.rm = TRUE) +
    facet_grid(rows = vars(River), cols = vars(Campaign), scales = "fixed", drop = FALSE) +
    scale_fill_manual(values = position_cols, drop = FALSE) +
    scale_x_discrete(drop = FALSE) +
    scale_y_continuous(
      expand = expansion(mult = c(0, 0.08)),
      labels = scales::label_number(accuracy = 0.001)
    ) +
    labs(
      x = "Sampling site",
      y = "Normalized gene abundance\n(copies per 16S rRNA gene copy)",
      title = g
    ) +
    theme_sci +
    theme(
      axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
      strip.text.x = element_text(size = 9),
      strip.text.y = element_text(size = 9),
      legend.position = "top"
    )
  
  ggsave(
    filename = file.path(detail_dir, paste0("Spatiotemporal_site_", g, ".png")),
    plot = p_detail,
    width = 15.5,
    height = 6.5,
    units = "in",
    dpi = png_dpi,
    bg = "white"
  )
  
  ggsave(
    filename = file.path(detail_dir, paste0("Spatiotemporal_site_", g, ".pdf")),
    plot = p_detail,
    width = 15.5,
    height = 6.5,
    units = "in",
    device = cairo_pdf
  )
}

# ---------------------------
# 12. 每个基因的时间×空间分区汇总图
# ---------------------------
gene_dir <- file.path(output_dir, "Position_summary_each_gene")
if (!dir.exists(gene_dir)) dir.create(gene_dir, recursive = TRUE)

for (g in gene_order) {
  ds <- summary_position %>% filter(Gene == g)
  dl <- gene_long %>% filter(Gene == g)
  if (nrow(ds) == 0) next
  
  p_gene <- ggplot(ds, aes(x = Campaign, y = Mean, fill = Position)) +
    geom_col(
      position = position_dodge(width = 0.80),
      width = 0.72,
      colour = "black",
      linewidth = 0.22
    ) +
    geom_errorbar(
      data = ds %>% filter(n > 1, !is.na(SE)),
      aes(ymin = pmax(Mean - SE, 0), ymax = Mean + SE),
      position = position_dodge(width = 0.80),
      width = 0.18,
      linewidth = 0.35
    ) +
    geom_point(
      data = dl,
      aes(x = Campaign, y = Abundance, fill = Position, group = Position),
      inherit.aes = FALSE,
      shape = 21,
      colour = "black",
      stroke = 0.22,
      size = 1.8,
      alpha = 0.72,
      position = position_jitterdodge(
        jitter.width = 0.08,
        dodge.width = 0.80,
        seed = 119
      )
    ) +
    facet_wrap(~ River, ncol = 1, scales = "free_y") +
    scale_fill_manual(values = position_cols, drop = FALSE) +
    scale_x_discrete(drop = FALSE) +
    scale_y_continuous(
      expand = expansion(mult = c(0, 0.10)),
      labels = scales::label_number(accuracy = 0.001)
    ) +
    labs(
      x = "Sampling campaign",
      y = "Normalized gene abundance\n(copies per 16S rRNA gene copy)",
      title = g
    ) +
    theme_sci
  
  ggsave(
    filename = file.path(gene_dir, paste0("Position_summary_", g, ".png")),
    plot = p_gene,
    width = 8.2,
    height = 7.5,
    units = "in",
    dpi = png_dpi,
    bg = "white"
  )
  
  ggsave(
    filename = file.path(gene_dir, paste0("Position_summary_", g, ".pdf")),
    plot = p_gene,
    width = 8.2,
    height = 7.5,
    units = "in",
    device = cairo_pdf
  )
}

cat("\n==============================================\n")
cat("绘图完成。\n")
cat("输出目录：", normalizePath(output_dir), "\n")
cat("主要输出：\n")
cat("1) Main_10genes_Tonghui_River.png/pdf\n")
cat("2) Main_10genes_Qing_River.png/pdf\n")
cat("3) Site_level_each_gene/\n")
cat("4) Position_summary_each_gene/\n")
cat("5) Spatiotemporal_gene_plot_data.xlsx\n")
cat("==============================================\n")
