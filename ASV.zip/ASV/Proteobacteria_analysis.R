############################################################
# Proteobacteria genus-level analysis
#
# Input:
# taxonomy(1).csv
# genus_abundance_final(2).xlsx
#
############################################################


library(tidyverse)
library(readxl)
library(openxlsx)
library(pheatmap)
library(ggplot2)


graphics.off()


############################################################
# 1. Create output folders
############################################################


outdir <- "Proteobacteria_analysis"

figdir <- file.path(
  outdir,
  "Figures"
)

resdir <- file.path(
  outdir,
  "Results"
)


dir.create(
  figdir,
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  resdir,
  recursive = TRUE,
  showWarnings = FALSE
)



############################################################
# 2. Read taxonomy
############################################################


tax <- read.csv(
  
  "taxonomy.csv",
  
  header = TRUE,
  
  check.names = FALSE,
  
  stringsAsFactors = FALSE
  
)



head(tax)



############################################################
# 3. Extract Proteobacteria genera
############################################################


tax_proteo <- tax %>%
  
  filter(
    
    grepl(
      "p__Proteobacteria",
      Taxon
    )
    
  )



# extract genus name

tax_proteo$Genus <-
  
  str_extract(
    
    tax_proteo$Taxon,
    
    "g__[^;]+"
    
  )



tax_proteo$Genus <-
  
  gsub(
    
    "g__",
    
    "",
    
    tax_proteo$Genus
    
  )



# remove NA

proteo_genus <- unique(
  
  tax_proteo$Genus[
    
    !is.na(tax_proteo$Genus)
    
  ]
  
)



write.xlsx(
  
  data.frame(
    
    Proteobacteria_Genus=
      proteo_genus
    
  ),
  
  file.path(
    
    resdir,
    
    "Proteobacteria_genus_list.xlsx"
    
  )
  
)



############################################################
# 4. Read genus abundance
############################################################


genus <- read_excel(
  
  "genus_abundance_final.xlsx",
  
  sheet="Genus_abundance"
  
)


genus <- as.data.frame(genus)



rownames(genus) <- genus$SampleID


genus$SampleID <- NULL



genus[] <- lapply(
  
  genus,
  
  as.numeric
  
)



############################################################
# 5. Match Proteobacteria genera
############################################################


common_genus <-
  
  intersect(
    
    colnames(genus),
    
    proteo_genus
    
  )



cat(
  "Proteobacteria genus number:",
  length(common_genus),
  "\n"
)



proteo_matrix <-
  
  genus[,common_genus,drop=FALSE]



write.xlsx(
  
  data.frame(
    
    SampleID=rownames(proteo_matrix),
    
    proteo_matrix
    
  ),
  
  file.path(
    
    resdir,
    
    "Proteobacteria_genus_abundance.xlsx"
    
  )
  
)



############################################################
# 6. Metadata
############################################################

metadata

############################################################
# 7. Top15 composition
############################################################


mean_abundance <-
  
  colMeans(
    
    proteo_matrix,
    
    na.rm=TRUE
    
  )



top15 <-
  
  names(
    
    sort(
      
      mean_abundance,
      
      decreasing=TRUE
      
    )[1:min(15,length(mean_abundance))]
    
  )



composition <-
  
  proteo_matrix[,top15]



composition$Others <-
  
  1-rowSums(composition)



composition_long <-
  
  composition %>%
  
  rownames_to_column(
    "SampleID"
  )%>%
  
  pivot_longer(
    
    cols=-SampleID,
    
    names_to="Genus",
    
    values_to="Abundance"
    
  )%>%
  
  left_join(
    
    metadata,
    
    by="SampleID"
    
  )



composition_plot <-
  
  composition_long %>%
  
  group_by(
    
    Campaign,
    
    River,
    
    Genus
    
  )%>%
  
  summarise(
    
    Mean_abundance=
      mean(Abundance),
    
    .groups="drop"
    
  )



p1 <- ggplot(
  
  composition_plot,
  
  aes(
    
    x=Campaign,
    
    y=Mean_abundance,
    
    fill=Genus
    
  )
  
)+
  
  geom_bar(
    
    stat="identity"
    
  )+
  
  facet_wrap(~River)+
  
  theme_bw()+
  
  theme(
    
    axis.text.x=
      
      element_text(
        
        angle=45,
        
        hjust=1
        
      ),
    
    legend.position="top"
    
  )+
  
  labs(
    
    x=NULL,
    
    y="Relative abundance"
    
  )



ggsave(
  
  file.path(
    
    figdir,
    
    "Proteobacteria_Top15_composition.pdf"
    
  ),
  
  p1,
  
  width=12,
  
  height=7
  
)



############################################################
# 8. Heatmap
############################################################


top30 <-
  
  names(
    
    sort(
      
      mean_abundance,
      
      decreasing=TRUE
      
    )[1:min(30,length(mean_abundance))]
    
  )



heat <- proteo_matrix[,top30]


heat_z <- scale(heat)



pheatmap(
  
  t(heat_z),
  
  cluster_rows=TRUE,
  
  cluster_cols=TRUE,
  
  filename=file.path(
    
    figdir,
    
    "Proteobacteria_Top30_heatmap.pdf"
    
  ),
  
  width=12,
  
  height=10
  
)



############################################################
# 9. Key nitrogen-related genera
############################################################


key_genus <- c(
  
  "Dechloromonas",
  
  "Methylotenera",
  
  "Acidovorax",
  
  "Pseudomonas",
  
  "Hydrogenophaga"
  
)



key_genus <-
  
  intersect(
    
    key_genus,
    
    colnames(proteo_matrix)
    
  )



key_long <-
  
  proteo_matrix[,key_genus] %>%
  
  rownames_to_column(
    "SampleID"
  )%>%
  
  pivot_longer(
    
    cols=-SampleID,
    
    names_to="Genus",
    
    values_to="Abundance"
    
  )%>%
  
  left_join(
    
    metadata,
    
    by="SampleID"
    
  )



p2 <- ggplot(
  
  key_long,
  
  aes(
    
    x=Campaign,
    
    y=Abundance,
    
    color=Genus,
    
    group=Genus
    
  )
  
)+
  
  stat_summary(
    
    fun=mean,
    
    geom="line",
    
    linewidth=1
    
  )+
  
  stat_summary(
    
    fun=mean,
    
    geom="point",
    
    size=3
    
  )+
  
  theme_bw()+
  
  labs(
    
    x=NULL,
    
    y="Relative abundance"
    
  )



ggsave(
  
  file.path(
    
    figdir,
    
    "Key_Proteobacteria_genera_time.pdf"
    
  ),
  
  p2,
  
  width=10,
  
  height=6
  
)



############################################################
# 10. Difference analysis
############################################################


proteo_long <-
  
  proteo_matrix %>%
  
  rownames_to_column(
    "SampleID"
  )%>%
  
  pivot_longer(
    
    cols=-SampleID,
    
    names_to="Genus",
    
    values_to="Abundance"
    
  )%>%
  
  left_join(
    
    metadata,
    
    by="SampleID"
    
  )



KW_test <- function(x,g){
  
  if(length(unique(g))<2){
    
    return(NA)
    
  }
  
  kruskal.test(
    x,
    g
  )$p.value
  
}



difference <-
  
  proteo_long %>%
  
  group_by(Genus) %>%
  
  summarise(
    
    Campaign_p =
      KW_test(
        Abundance,
        Campaign
      ),
    
    River_p =
      KW_test(
        Abundance,
        River
      ),
    
    Position_p =
      KW_test(
        Abundance,
        Position
      ),
    
    .groups="drop"
    
  )%>%
  
  mutate(
    
    Campaign_FDR=p.adjust(Campaign_p,"BH"),
    
    River_FDR=p.adjust(River_p,"BH"),
    
    Position_FDR=p.adjust(Position_p,"BH")
    
  )



write.xlsx(
  
  difference,
  
  file.path(
    
    resdir,
    
    "Proteobacteria_difference.xlsx"
    
  )
  
)



cat(
  
  "Proteobacteria analysis finished!\n"
  
)

############################################################
# Tonghui River composition
############################################################


tonghui_plot <- composition_plot %>%
  
  filter(
    River=="Tonghui"
  )



p_tonghui <- ggplot(
  
  tonghui_plot,
  
  aes(
    x=Campaign,
    y=Mean_abundance,
    fill=Genus
  )
  
)+
  
  
  geom_bar(
    
    stat="identity",
    
    width=0.8
    
  )+
  
  
  theme_bw()+
  
  
  theme(
    
    panel.grid=element_blank(),
    
    axis.text.x=
      element_text(
        angle=45,
        hjust=1
      ),
    
    legend.position="right"
    
  )+
  
  
  labs(
    
    title="Tonghui River",
    
    x=NULL,
    
    y="Relative abundance"
    
  )



ggsave(
  
  file.path(
    figdir,
    "Proteobacteria_Tonghui_Top15_composition.pdf"
  ),
  
  p_tonghui,
  
  width=6,
  
  height=6
  
)
############################################################
# Qing River composition
############################################################


qing_plot <- composition_plot %>%
  
  filter(
    River=="Qing"
  )



p_qing <- ggplot(
  
  qing_plot,
  
  aes(
    x=Campaign,
    y=Mean_abundance,
    fill=Genus
  )
  
)+
  
  
  geom_bar(
    
    stat="identity",
    
    width=0.8
    
  )+
  
  
  theme_bw()+
  
  
  theme(
    
    panel.grid=element_blank(),
    
    axis.text.x=
      element_text(
        angle=45,
        hjust=1
      ),
    
    legend.position="right"
    
  )+
  
  
  labs(
    
    title="Qing River",
    
    x=NULL,
    
    y="Relative abundance"
    
  )



ggsave(
  
  file.path(
    figdir,
    "Proteobacteria_Qing_Top15_composition.pdf"
  ),
  
  p_qing,
  
  width=6,
  
  height=6
  
)