import h2o
from h2o.automl import H2OAutoML
import pandas as pd
from pdpbox import pdp, get_dataset, info

# 初始化 H2O
h2o.init(port=54322)

# 加载数据
data = pd.read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")
data_h2o = h2o.H2OFrame(data)

# 定义目标变量和特征
target = "gdh"
predictors = ['NH3_N', 'NO3_N', 'NO2_N', 'TN', 'CODcr', 'PO4', 'TP',
              'TOC', 'COND', 'TDS', 'ORP', 'pH', 'Temp', 'DO', 'Chl_a']

# 划分数据集
train, test = data_h2o.split_frame(ratios=[0.85], seed=1234)

# 运行 H2O AutoML
aml = H2OAutoML(max_models=20, seed=1234, exclude_algos=["DeepLearning", "StackedEnsemble", "XGBoost", "GBM", "GLM"])
aml.train(x=predictors, y=target, training_frame=train, validation_frame=test)

# 获取最优模型
best_model = aml.leader

# 转换为 H2O 模型
h2o_model = best_model.as_h2o_frame()

# 使用 pdpbox 绘制二维部分依赖图
pdp_tds_temp = pdp.pdp_interact(
    model=best_model,
    dataset=data,
    model_features=predictors,
    features=['TDS', 'Temp']
)

# 绘制图形
pdp.pdp_interact_plot(
    pdp_tds_temp,
    feature_names=['TDS', 'Temp'],
    plot_type='contour',
    x_quantile=True,
    plot_pdp=True
)