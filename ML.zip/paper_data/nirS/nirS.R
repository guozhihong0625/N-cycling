setwd("E:\\Rdoc\\paper_data\\nirS")
library(h2o)
library(openxlsx)
library(iml)
library(ggplot2)
library(readxl)
library(dplyr)

library(systemfonts)


Sys.setenv(JAVA_HOME="D:\\Java\\jdk-22_windows-x64_bin\\jdk-22.0.1")
# 初始化 h2o 环境
h2o.init(port = 54322)  # 使用非默认端口
# 读取数据
data<- read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")
# 将数据加载为 H2OFrame 对象
data_h2o <- as.h2o(data)


# 定义目标变量和解释变量
target <- "nirS"
predictors<- c('NH3_N','NO3_N','NO2_N','TN','CODcr','PO4','TP',
               'TOC','COND','TDS','ORP','pH','Temp','DO','Chl_a')


# 划分数据集为80%的训练集和20%的测试集
splits <- h2o.splitFrame(data_h2o, ratios = 0.85, seed = 1234)

# 获取训练集和测试集
train <- splits[[1]]
test <- splits[[2]]

# 定义需要排除的模型
excluded_algos <- c("DeepLearning", "StackedEnsemble", "XGBoost")

# 运行 AutoML
aml <- h2o.automl(
  x = predictors,
  y = target,
  training_frame = train,  # 使用划分后的训练集
  validation_frame = test,  # 使用划分后的测试集
  max_models = 20,
  exclude_algos = excluded_algos,  # 排除指定模型
  seed = 1234
)

# 获取最优模型
best_model <- aml@leader
print(best_model)

# 获取模型性能
perf_train <- h2o.performance(best_model, train = TRUE)  # 训练集性能
perf_test <- h2o.performance(best_model, valid = TRUE)  # 测试集性能

# 获取 MSE 和 R²
train_mse <- h2o.mse(perf_train)
train_r2 <- h2o.r2(perf_train)
test_mse <- h2o.mse(perf_test)
test_r2 <- h2o.r2(perf_test)

cat("训练集 MSE:", train_mse, "\n")
cat("训练集 R²:", train_r2, "\n")
cat("测试集 MSE:", test_mse, "\n")
cat("测试集 R²:", test_r2, "\n")


# 指定保存模型的路径
model_path <- "model"

# 保存最佳模型
h2o.saveModel(best_model, path = model_path, force = TRUE)

# 初始化结果存储列表
results <- list()

# 假设最佳模型已选定为 best_model，并且 data 为原始数据集
set.seed(1234)  # 设置随机种子
train_ratio <- 0.85  # 训练集比例

for (i in 1:30) {
  # 随机划分训练集和测试集
  train_idx <- sample(1:nrow(data), size = floor(train_ratio * nrow(data)))
  train_data <- as.h2o(data[train_idx, ])
  test_data <- as.h2o(data[-train_idx, ])
  
  # 训练集性能
  train_perf <- h2o.performance(best_model, train_data)
  train_r2 <- h2o.r2(train_perf)
  train_mse <- h2o.mse(train_perf)
  
  # 测试集性能
  test_perf <- h2o.performance(best_model, test_data)
  test_r2 <- h2o.r2(test_perf)
  test_mse <- h2o.mse(test_perf)
  
  # 保存每次的结果
  results[[i]] <- data.frame(
    Iteration = i,
    Train_R2 = train_r2,
    Train_MSE = train_mse,
    Test_R2 = test_r2,
    Test_MSE = test_mse,
    R2_Diff = train_r2 - test_r2
  )
}

# 合并结果为一个数据框
results_df <- do.call(rbind, results)

# 计算平均值并打印
cat("平均训练集 R²:", mean(results_df$Train_R2), "\n")
cat("平均测试集 R²:", mean(results_df$Test_R2), "\n")
cat("平均训练集 MSE:", mean(results_df$Train_MSE), "\n")
cat("平均测试集 MSE:", mean(results_df$Test_MSE), "\n")


#测试模型稳定性
library(ggplot2)

# 绘制并保存训练集 R² 图
train_plot <- ggplot(results_df, aes(x = Iteration, y = Train_R2)) +
  geom_point(color = "blue", size = 3, alpha = 0.7) +   # 散点
  geom_line(color = "blue", size = 1, alpha = 0.8) +    # 连线
  theme_minimal() +
  labs(
    title = "Train Set R² Over 30 Iterations",
    x = "Iteration",
    y = "R²"
  ) +
  scale_y_continuous(limits = c(0, 1))

# 保存训练集图为 PNG
ggsave("Train_Set_R2_Plot.png", plot = train_plot, width = 8, height = 6)

# 绘制并保存测试集 R² 图
test_plot <- ggplot(results_df, aes(x = Iteration, y = Test_R2)) +
  geom_point(color = "red", size = 3, alpha = 0.7) +    # 散点
  geom_line(color = "red", size = 1, alpha = 0.8) +     # 连线
  theme_minimal() +
  labs(
    title = "Test Set R² Over 30 Iterations",
    x = "Iteration",
    y = "R²"
  ) +
  scale_y_continuous(limits = c(0, 1))

# 保存测试集图为 PNG
ggsave("Test_Set_R2_Plot.png", plot = test_plot, width = 8, height = 6)

# 导出为 Excel 文件
library(writexl)
library(dplyr)

write_xlsx(results_df, "Model_Stability_Results.xlsx")

# 对 R2_Diff 绝对值进行升序排列
results_df <- results_df %>%
  mutate(R2_Diff_abs = abs(R2_Diff)) %>%  # 创建一个新的列用于存储 R2_Diff 的绝对值
  arrange(R2_Diff_abs) %>%  # 按 R2_Diff_abs 升序排列
  select(-R2_Diff_abs)  # 删除临时的 R2_Diff_abs 列

# 保存排序后的结果到 Excel 文件
write_xlsx(results_df, "End_Results.xlsx")










# 确定 R2_Diff 的绝对值最小的一次迭代
min_diff_idx <- 15

# 根据最优索引划分训练集和测试集
set.seed(1234)  # 确保分割一致
train_idx <- sample(1:nrow(data), size = floor(train_ratio * nrow(data)))
if (min_diff_idx > 1) {
  for (i in 2:min_diff_idx) {
    train_idx <- sample(1:nrow(data), size = floor(train_ratio * nrow(data)))
  }
}

# 划分训练集和测试集
train_data <- data[train_idx, ]
test_data <- data[-train_idx, ]

# 转换为 H2O 对象
train_h2o <- as.h2o(train_data)
test_h2o <- as.h2o(test_data)

# 预测训练集和测试集
train_predictions <- as.data.frame(h2o.predict(best_model, train_h2o))
test_predictions <- as.data.frame(h2o.predict(best_model, test_h2o))

# 提取实际值和预测值
train_actual <- train_data$nirS  # 替换为实际目标变量名
test_actual <- test_data$nirS

train_predicted <- train_predictions$predict
test_predicted <- test_predictions$predict

# 合并实际值与预测值
train_results <- data.frame(
  Actual = train_actual,
  Predicted = train_predicted,
  Dataset = "Train"
)

test_results <- data.frame(
  Actual = test_actual,
  Predicted = test_predicted,
  Dataset = "Test"
)

# 合并训练集和测试集结果
combined_results <- rbind(train_results, test_results)

# 格式化数据框中的数值列，保留 5 位小数
combined_results[] <- lapply(combined_results, function(x) if (is.numeric(x)) round(x, 5) else x)

# 保存为 CSV 文件
write.csv(combined_results, "combined_nirS_values.csv", row.names = FALSE)


#---------------------------------------------------------
combined_results <- read.csv("E:\\Rdoc\\paper_data\\nirS\\combined_nirS_values.csv")
# 定义颜色
cols_2 <- c("#BB474D", "#4E6691")  # 蓝色和红色

# 创建 ggplot 对象
# 创建 ggplot 对象
plot <- ggplot(combined_results, aes(x = Actual, y = Predicted, color = Dataset, fill = Dataset)) +
  # 绘制散点图
  geom_point(shape = 21, colour = "black", size = 5, stroke = 0.3, aes(fill = Dataset)) +
  # 设置颜色
  scale_fill_manual(values = cols_2) +
  scale_color_manual(values = cols_2) +
  # 添加线性回归拟合线
  geom_smooth(
    data = subset(combined_results, Dataset == 'Train'),
    method = "lm",
    colour = cols_2[1],
    fill = cols_2[1],
    alpha = 0.2,
    linetype = "solid"
  ) +
  geom_smooth(
    data = subset(combined_results, Dataset == 'Test'),
    method = "lm",
    colour = cols_2[2],
    fill = cols_2[2],
    alpha = 0.2,
    linetype = "solid"
  ) +
  # 设置 X 和 Y 轴范围
  xlim(min(combined_results$Actual), max(combined_results$Actual)) +
  ylim(min(combined_results$Actual), max(combined_results$Actual)) +
  # 添加标签
  xlab("Observed lg(nirS) abundance") +
  ylab("Predicted lg(nirS) abundance") +
  labs(subtitle = "Abundance of nirS predicted by EFs") +
  # 添加文字标签
  geom_text(
    x = min(combined_results$Actual) + 0.02 * (max(combined_results$Actual) - min(combined_results$Actual)),
    y = max(combined_results$Predicted) -0.02- 0.02 * (max(combined_results$Predicted) - min(combined_results$Predicted)),
    label = paste0("Training：R²=0.776", 
                   " RMSE=0.140"), 
    color = cols_2[2], 
    size = 6, 
    hjust = 0
  ) +
  geom_text(
    x = min(combined_results$Actual) + 0.02 * (max(combined_results$Actual) - min(combined_results$Actual)), 
    y = max(combined_results$Predicted) -0.003- 0.1 * (max(combined_results$Predicted) - min(combined_results$Predicted)),
    label = paste0("Testing ：R²=0.777", 
                   " RMSE=0.178"), 
    color = cols_2[1], 
    size = 6, 
    hjust = 0
  ) +
  # 设置主题
  theme_minimal() +
  theme(
    panel.grid = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 0.8),
    legend.position = "none",
    axis.title = element_text(size = 15, face = "bold"),  # 修改字体大小为 18
    axis.text = element_text(size = 15),                 # 修改轴刻度字体大小为 15
    plot.subtitle = element_text(size = 18, face = "bold", hjust = 0)
  ) +
  # 添加对角线
  geom_abline(intercept = 0, slope = 1, linewidth = 0.6, linetype = "dashed", color = "gray50") +
  # 设置 X 和 Y 轴的刻度格式为一位小数
  scale_x_continuous(labels = scales::number_format(accuracy = 0.1)) +
  scale_y_continuous(labels = scales::number_format(accuracy = 0.1))

# 定义输出 PDF 文件名和路径
output_pdf <- "nirS_Fitting_Plot.pdf"

# 保存图形为 PDF
ggsave(
  filename = output_pdf,  # 文件名
  plot = plot,            # 绘图对象
  device = "pdf",         # 保存为 PDF 格式
  width = 6,              # 宽度（单位为英寸）
  height = 6,             # 高度（单位为英寸）
  units = "in",           # 尺寸单位
  dpi = 600               # 分辨率
)


#---------------------------------------------------------------------------------
#TOP15变量 柱状图
# 获取模型的变量重要度
model<- best_model
var_importance <- h2o.varimp(model)
# 提取前15个重要度
top_15_var_importance <- head(var_importance, 15)
# 转换为数据框
var_importance_df <- as.data.frame(top_15_var_importance)


# 加载dplyr包
library(dplyr)
# 选择需要的列并调整percentage列的小数位数，保存为CSV文件
var_importance_df %>%
  select(variable, percentage) %>%  # 选择列名为variable和percentage的列
  mutate(percentage = round(percentage, 3)) %>%  # 将percentage列的小数保留3位
  write.csv("variable_importance_percentage.csv", row.names = FALSE)  # 保存为CSV文件，row.names = FALSE避免保存行名



library(dplyr)
library(ggplot2)

# 读取数据
data <- read.csv("E:/Rdoc/paper_data/nirS/variable_importance_percentage.csv")

# 自定义顺序
shunxu <- c('Chl_a', 'CODcr', 'COND', 'DO', 'NH3_N', 'NO2_N', 'NO3_N', 
            'ORP', 'pH', 'PO4', 'TDS', 'Temp', 'TN', 'TOC', 'TP')

# 自定义颜色（确保与变量名称一一对应）
color_palette <- c(
  'Chl_a' = '#FF6F61',   # Warm red (暖红)
  'CODcr' = '#FF8C42',   # Soft orange (柔橙)
  'COND' = '#FFA056',    # Peach orange (桃橙)
  'DO' = '#FFC156',      # Warm gold (暖金)
  'NH3_N' = '#FFD866',   # Golden yellow (金黄)
  'NO2_N' = '#FFE382',   # Light golden (浅金)
  'NO3_N' = '#E8D18B',   # Sand yellow (沙黄)
  'ORP' = '#BFD8A2',     # Soft greenish (柔绿)
  'pH' = '#88C9E4',      # Soft sky blue (柔天蓝)
  'PO4' = '#61B4E4',     # Medium sky blue (中天蓝)
  'TDS' = '#3E99E6',     # Clear blue (清蓝)
  'Temp' = '#1E88E5',    # Ocean blue (海洋蓝)
  'TN' = '#1A73E8',      # Strong blue (强蓝)
  'TOC' = '#1565C0',     # Medium navy (中海军蓝)
  'TP' = '#0D47A1'       # Navy blue (海军蓝)
)

# 调整数据顺序并确保因子水平
data$variable <- factor(data$variable, levels = shunxu)

# 绘制甜甜圈图
p <- ggplot(data, aes(x = 2, y = percentage, fill = variable)) +
  geom_bar(stat = "identity", width = 1) +  # 设置宽度为1
  coord_polar(theta = "y", start = pi/2, direction = -1) +  # 从顶部开始，逆时针绘图
  xlim(0.5, 2.5) +  # 创建空心效果
  theme_void() +  # 去除背景
  scale_fill_manual(values = color_palette) +  # 配置颜色
  theme(legend.position = "right") +  # 图例位置
  geom_text(aes(label = paste0(round(percentage * 100, 1), "%")), 
            position = position_stack(vjust = 0.5), size = 5)  # 添加标签

# 显示图形
print(p)

# 保存为PDF
ggsave("nirS_重要度排序_甜甜圈.pdf", plot = p, width = 8, height = 8, units = "in", dpi = 300)


#----------------------------------------------------

#3*5大数字
#【1D-PDP】——解释变量和预测变量之间的部分依赖分析图
# 初始化图像列表
# 选择前15个重要特征
library(h2o)
library(dplyr)
library(ggplot2)
library(gridExtra) 

# 读取变量重要性
train_df <- as.data.frame(train_data)
var_importance <- h2o.varimp(model)
top15_features <- var_importance[1:15, "variable"]

# 定义PDP绘制函数
draw_pdp <- function(feature_name, model, train_df) {
  unique_feature <- train_df %>%
    dplyr::select(!!rlang::sym(feature_name)) %>%
    distinct()
  unique_feature_h2o <- as.h2o(unique_feature)
  predictions_h2o <- h2o.predict(model, newdata = unique_feature_h2o)
  predictions_df <- as.data.frame(predictions_h2o)
  pdp_data <- bind_cols(unique_feature, predictions_df)
  
  return(ggplot(pdp_data, aes_string(x = feature_name, y = "predict")) +
           geom_smooth(method = 'loess') +
           labs(x = feature_name ,
                title = gsub("Partial Dependency Plot of ", "", paste("Partial Dependency Plot of", feature_name)),
                subtitle = NULL) +
           theme_minimal() +
           theme_bw() +
           theme(axis.title.x = element_text(size = 30, face = "bold"),  # 增大X轴标题字体
                 axis.title.y = element_blank(),  # 去掉Y轴标题
                 axis.text.x = element_text(face = "bold", size = 20),   # 增大X轴刻度字体
                 axis.text.y = element_text(face = "bold", size = 20), 
                 plot.title = element_text(face = "bold", size = 20, hjust = 2))  # 增大标题字体
  )  
}

# 指定变量
top15_features <-c('pH','TN','TP','NO3_N','COND','PO4','Chl_a','Temp',
                   'NH3_N','DO', 'TDS','NO2_N','TOC','ORP','CODcr')

# 绘制PDP图
pdp_plots <- lapply(top15_features, function(feature) {
  draw_pdp(feature, model, train_df)
})

# 转换为grob对象
gplots_list <- lapply(pdp_plots, ggplotGrob)

# 设置输出文件为PDF
pdf("nirS_PDP.pdf", width = 30, height = 30)  # 根据5行3列的布局设置合适的页面大小
grid.arrange(grobs = gplots_list, nrow = 5, ncol = 5, 
             widths = rep(1, 5), heights = rep(1, 5))  # 设置宽度和高度的比例相等
dev.off()  # 关闭PDF设备

# 同时生成PNG文件
png("nirS_PDP.png", width = 6000, height = 6000, res = 300)  # 设置高分辨率的PNG输出
grid.arrange(grobs = gplots_list, nrow = 5, ncol = 5, 
             widths = rep(1, 5), heights = rep(1, 5))  # 同样的布局
dev.off()  # 关闭PNG设备

#-----------------------
#SHAP依赖图

library(shapviz)

# 去除第 16列及之后的列
traindatax <- train_df[, -c(16:ncol(train_df))]
features<- c( 'Chl_a','CODcr','COND','DO','NH3_N','NO2_N',
              'NO3_N','ORP','pH','PO4','Temp','TN','TOC','TP','TDS')

shp <- shapviz(model, X_pred = traindatax[, features], X = traindatax)
pdf("nirS_SHAP.pdf", width = 10, height = 10)
sv_importance(shp, kind = "beeswarm", size = 5) +
  theme_minimal(base_size = 15) +  # 更改主题为白色背景
  theme(plot.title = element_text(size = 30),
        axis.title.x = element_text(size = 30),  # X轴标题字体大小
        axis.title.y = element_text(size = 30),  # Y轴标题字体大小
        axis.text.x = element_text(size = 20),   # X轴刻度字体大小
        axis.text.y = element_text(size = 20),   # Y轴刻度字体大小
        legend.text = element_text(size = 20),   # 图例文本字体大小
        legend.position = "right",  # 图例位置放置于右侧
        legend.direction = "vertical",  # 设置图例为垂直布局
        legend.title = element_text(size = 25, angle = 90,hjust = 0.5),  # 旋转图例标题90度
        legend.title.position = "top"  # 保持标题在图例的上方
  ) +
  guides(color = guide_colorbar(title.position = "right", barwidth = 0.5, barheight = 40))  # 图例标题右侧并调整图例条大小

dev.off()





#特征重要度排序图---------------------------------
library(shapviz)

# 确保已加载 traindatax 和 features，并生成 shapviz 对象
shp <- shapviz(model, X_pred = traindatax[, features], X = traindatax)

# 保存特征重要度排序图为 PDF 文件
pdf("nirS_Feature_Importance.pdf", width = 10, height = 10)

# 绘制特征重要度排序图
sv_importance(shp, kind = "bar", size = 5) +
  theme_minimal(base_size = 15) +  # 设置主题为白色背景
  theme(
    plot.title = element_text(size = 30),  # 设置标题字体大小
    axis.title.x = element_text(size = 30),  # 设置X轴标题字体大小
    axis.title.y = element_text(size = 30),  # 设置Y轴标题字体大小
    axis.text.x = element_text(size = 20),   # 设置X轴刻度字体大小
    axis.text.y = element_text(size = 20),   # 设置Y轴刻度字体大小
    legend.text = element_text(size = 20),   # 图例文本字体大小
    legend.position = "none"  # 去掉图例
  )

dev.off()






#瀑布图--------------------------------
# 确保生成 SHAP 对象
shp <- shapviz(model, X_pred = traindatax[, features], X = traindatax)

# 绘制 SHAP 瀑布图
waterfall_plot <- sv_waterfall(shp,
                               row_id = 1,  # 修改为你想分析的样本索引
                               fill_colors = c("#3b528b", "#5ec962")) +  # 修改颜色（可选）
  theme_bw() +  # 设置主题为白色背景
  ggtitle("SHAP Waterfall for Sample 1") +  # 修改标题
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", color = "black"),
    axis.title.x = element_text(size = 20),  # 设置 x 轴标题字号
    axis.title.y = element_text(size = 20),  # 设置 y 轴标题字号
    axis.text.x = element_text(size = 15),   # 设置 x 轴刻度字号
    axis.text.y = element_text(size = 15),   # 设置 y 轴刻度字号
    plot.margin = margin(10, 10, 10, 10)     # 调整边距
  )

# 保存图像为 PDF
pdf("SHAP_Waterfall_Sample1.pdf", width = 10, height = 8)  # 设置图像尺寸
print(waterfall_plot)  # 输出图像
dev.off()

#二维--   --------

# 加载模型
model_h2o<- h2o.loadModel(path = "E:\\Rdoc\\paper_data\\nirS\\model\\XRT_1_AutoML_1_20250302_171651")

#2D_Temp_pH--------------
# 生成一个网格，用于绘制二维部分依赖图
Temp_vals <- seq(min(data$Temp), max(data$Temp), length.out = 50)
chla_vals <- seq(min(data$pH), max(data$pH), length.out = 50)
grid <- expand.grid(Temp = Temp_vals, pH = chla_vals)

# 将网格转换为 H2O 数据框
grid_h2o <- as.h2o(grid)

# 生成网格上的预测
predictions <- h2o.predict(model_h2o, grid_h2o)

# 将预测结果添加到网格
grid$Predicted <- as.vector(predictions$predict)

# 创建自定义颜色渐变
rwb <- colorRampPalette(c("blue", "white", "red"))

# 绘制二维部分依赖图
library(ggplot2)
ggplot(grid, aes(x = Temp, y = pH, fill = Predicted)) +
  geom_tile() +
  scale_fill_gradientn(colors = rwb(100)) +  # 使用自定义的颜色渐变
  labs(title = "2D Partial Dependence Plot",
       x = "Temp",
       y = "pH",
       fill = "Predicted\nValue") +
  theme_minimal()
ggsave("2D_Temp_pH.pdf", width = 8, height = 6)


h2o.shutdown(prompt = FALSE)




