setwd("E:\\Rdoc\\paper_data\\nirS")
# 加载必要的库
library(h2o)
library(readxl)
library(ggplot2)

# 初始化 H2O 环境
Sys.setenv(JAVA_HOME = "D:\\Java\\jdk-22_windows-x64_bin\\jdk-22.0.1")
h2o.init(port = 54322)

# 读取数据
data <- read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")
data_h2o <- as.h2o(data)

# 定义目标变量和解释变量
target <- "nirS"
predictors <- c('NH3_N', 'NO3_N', 'NO2_N', 'TN', 'CODcr', 'PO4', 'TP',
                'TOC', 'COND', 'TDS', 'ORP', 'pH', 'Temp', 'DO', 'Chl_a')

# 划分数据集为 80% 的训练集和 20% 的测试集
splits <- h2o.splitFrame(data_h2o, ratios = 0.85, seed = 1234)

# 获取训练集和测试集
train <- splits[[1]]
test <- splits[[2]]

# 运行 AutoML
aml <- h2o.automl(
  x = predictors,
  y = target,
  training_frame = train,
  validation_frame = test,
  max_models = 20,
  exclude_algos = c("DeepLearning", "StackedEnsemble", "XGBoost", "GBM", "GLM"),
  seed = 1234
)

# 提取最优模型的参数
best_model <- aml@leader
print(best_model@parameters)
# 查看模型
print(best_model)
# 进行预测
# 在训练集和测试集上进行预测
train_predictions <- h2o.predict(best_model, newdata = train)
test_predictions <- h2o.predict(best_model, newdata = test)

# 计算 R² 和 RMSE
train_metrics <- h2o.performance(best_model, train)
test_metrics <- h2o.performance(best_model, test)

# 提取 R² 和 RMSE
train_r2 <- h2o.r2(train_metrics)
train_rmse <- h2o.rmse(train_metrics)

test_r2 <- h2o.r2(test_metrics)
test_rmse <- h2o.rmse(test_metrics)

# 打印结果
cat("Training Set Metrics:\n")
cat("R²:", train_r2, "\n")
cat("RMSE:", train_rmse, "\n")

cat("Test Set Metrics:\n")
cat("R²:", test_r2, "\n")
cat("RMSE:", test_rmse, "\n")

# 关闭 H2O 集群
h2o.shutdown()









library(caret)
library(randomForest)
data <- read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")

# 定义目标变量和解释变量
target <- "nirS"
predictors <- c('NH3_N', 'NO3_N', 'NO2_N', 'TN', 'CODcr', 'PO4', 'TP',
                'TOC', 'COND', 'TDS', 'ORP', 'pH', 'Temp', 'DO', 'Chl_a')

# 获取训练集和测试集
set.seed(1234)
indices <- sample(1:nrow(data), size = 0.85 * nrow(data))
train <- data[indices, ]
test <- data[-indices, ]
# 提取特征和目标变量
train_x <- train[, predictors]
train_y <- train[[target]]
test_x <- test[, predictors]
test_y <- test[[target]]
# 确保 train_y 是向量

# 构建随机森林模型
rf_model <- randomForest(
  x = train_x,
  y = train_y,
  ntree = 27,  # ntrees
  mtry = length(predictors) %/% 3,  # 默认为特征数的三分之一
  importance = TRUE,  # 计算特征重要性
  seed = 1234
)

# 查看模型
print(rf_model)
# 进行预测
# 在训练集上进行预测
train_predictions <- predict(rf_model, newdata = train_x)

# 在测试集上进行预测
test_predictions <- predict(rf_model, newdata = test_x)

# 计算 R² 和 RMSE
# 训练集性能
train_r2 <- R2(train_predictions, train_y)
train_rmse <- RMSE(train_predictions, train_y)

# 测试集性能
test_r2 <- R2(test_predictions, test_y)
test_rmse <- RMSE(test_predictions, test_y)

# 输出结果
cat("Training Set Performance:\n")
cat("R²:", train_r2, "\n")
cat("RMSE:", train_rmse, "\n\n")

cat("Test Set Performance:\n")
cat("R²:", test_r2, "\n")
cat("RMSE:", test_rmse, "\n")

#2D-------------------------
pred_vars <- c("pH", "ORP")

# 使用 pdp 包生成二维部分依赖图
pdp_plot <- pdp::partial(
  object = rf_model,            # 随机森林模型
  pred.var = pred_vars,         # 分析的变量
  train = train_x,               # 训练数据
  grid.resolution = 50,         # 网格分辨率
  chull = TRUE                  # 是否使用凸包
)

# 定义平滑的颜色渐变
colors <- colorRampPalette(c("blue", "white", "red"))(100)  # 生成 100 种颜色

# 设置 PDF 文件路径
pdf_file <- "2D_PDP_pH_ORP.pdf"

# 开始保存 PDF
pdf(pdf_file, width = 6, height = 5)  # 设置 PDF 文件的宽度和高度

# 绘制二维部分依赖图
pdp::plotPartial(
  pdp_plot,
  plot.title = paste("2D Partial Dependence Plot for", paste(pred_vars, collapse = " & ")),
  xlab = pred_vars[1],          # x轴标签
  ylab = pred_vars[2],          # y轴标签
  contour = TRUE,               # 是否绘制等高线
  plot.points = TRUE,           # 是否绘制数据点
  plot.lines = TRUE,            # 是否绘制线条
  plot.pdp = TRUE,              # 是否绘制部分依赖图
  grid.resolution = 100,        # 网格分辨率
  col.regions = colors          # 使用平滑的颜色渐变
)

# 结束保存 PDF
dev.off()



pred_vars <- c("Chl_a", "CODcr")

# 使用 pdp 包生成二维部分依赖图
pdp_plot <- pdp::partial(
  object = rf_model,            # 随机森林模型
  pred.var = pred_vars,         # 分析的变量
  train = train_x,               # 训练数据
  grid.resolution = 50,         # 网格分辨率
  chull = TRUE                  # 是否使用凸包
)

# 定义平滑的颜色渐变
colors <- colorRampPalette(c("blue", "white", "red"))(100)  # 生成 100 种颜色

# 设置 PDF 文件路径
pdf_file <- "2D_PDP_Chl_a_CODcr.pdf"

# 开始保存 PDF
pdf(pdf_file, width = 6, height = 5)  # 设置 PDF 文件的宽度和高度

# 绘制二维部分依赖图
pdp::plotPartial(
  pdp_plot,
  plot.title = paste("2D Partial Dependence Plot for", paste(pred_vars, collapse = " & ")),
  xlab = pred_vars[1],          # x轴标签
  ylab = pred_vars[2],          # y轴标签
  contour = TRUE,               # 是否绘制等高线
  plot.points = TRUE,           # 是否绘制数据点
  plot.lines = TRUE,            # 是否绘制线条
  plot.pdp = TRUE,              # 是否绘制部分依赖图
  grid.resolution = 100,        # 网格分辨率
  col.regions = colors          # 使用平滑的颜色渐变
)

# 结束保存 PDF
dev.off()
