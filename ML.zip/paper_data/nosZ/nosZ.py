import h2o
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from h2o.automl import H2OAutoML
from sklearn.model_selection import train_test_split
import shap
import os


# 初始化 H2O
h2o.init(port=54322)


# 读取数据
data = pd.read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")

data_h2o = h2o.H2OFrame(data)


# 定义变量
target = "nosZ"
predictors = ['NH3_N', 'NO3_N', 'NO2_N', 'TN', 'CODcr', 'PO4', 'TP',
              'TOC', 'COND', 'TDS', 'ORP', 'pH', 'Temp', 'DO', 'Chl_a']

# 划分数据集
train, test = data_h2o.split_frame(ratios=[0.85], seed=1234)

# 运行 AutoML
excluded_algos = ["DeepLearning", "StackedEnsemble", "XGBoost"]
aml = H2OAutoML(max_models=20, exclude_algos=excluded_algos, seed=1234)
aml.train(x=predictors, y=target, training_frame=train, validation_frame=test)

# 获取最佳模型
best_model = aml.leader
print(best_model)


# 模型评估
def evaluate_model(model, frame):
    perf = model.model_performance(frame)
    return perf.rmse(), perf.r2()


train_rmse, train_r2 = evaluate_model(best_model, train)
test_rmse, test_r2 = evaluate_model(best_model, test)

print(f"Train RMSE: {train_rmse}, R2: {train_r2}")
print(f"Test RMSE: {test_rmse}, R2: {test_r2}")

# 模型稳定性测试
results = []
for i in range(30):
    train_df, test_df = train_test_split(data, test_size=0.15, random_state=i)
    train_h = h2o.H2OFrame(train_df)
    test_h = h2o.H2OFrame(test_df)

    _, train_r2 = evaluate_model(best_model, train_h)
    _, test_r2 = evaluate_model(best_model, test_h)

    results.append({
        "Iteration": i + 1,
        "Train_R2": train_r2,
        "Test_R2": test_r2,
        "R2_Diff": train_r2 - test_r2
    })

results_df = pd.DataFrame(results)
print(f"Average Train R2: {results_df['Train_R2'].mean()}")
print(f"Average Test R2: {results_df['Test_R2'].mean()}")

# 保存模型
model_path = h2o.save_model(best_model, path="model", force=True)

# 可视化
plt.figure(figsize=(10, 6))
plt.plot(results_df['Iteration'], results_df['Train_R2'], 'b-', label='Train R2')
plt.plot(results_df['Iteration'], results_df['Test_R2'], 'r-', label='Test R2')
plt.xlabel('Iteration')
plt.ylabel('R-squared')
plt.legend()
plt.savefig('stability_plot.png')

# 变量重要性
var_imp = best_model.varimp(use_pandas=True)
plt.figure(figsize=(10, 6))
sns.barplot(x='scaled_importance', y='variable', data=var_imp)
plt.title('Variable Importance')
plt.savefig('variable_importance.png')

# SHAP 分析









# 关闭 H2O
h2o.cluster().shutdown()