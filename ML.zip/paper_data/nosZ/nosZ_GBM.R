# 加载必要的库
library(h2o)
library(readxl)
Sys.setenv(JAVA_HOME="D:\\Java\\jdk-22_windows-x64_bin\\jdk-22.0.1")
# 初始化 h2o 环境
h2o.init(port = 54322)  # 使用非默认端口

# 加载数据
data <- read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")
data_h2o <- as.h2o(data)

# 定义目标变量和解释变量
target <- "nosZ"
predictors <- c('NH3_N', 'NO3_N', 'NO2_N', 'TN', 'CODcr', 'PO4', 'TP',
                'TOC', 'COND', 'TDS', 'ORP', 'pH', 'Temp', 'DO', 'Chl_a')

# 划分数据集为80%的训练集和20%的测试集
splits <- h2o.splitFrame(data_h2o, ratios = 0.85, seed = 1234)
train <- splits[[1]]
test <- splits[[2]]

# 训练 GBM 模型
gbm_model <- h2o.gbm(
  x = predictors,
  y = target,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,  # 设置树的数量
  max_depth = 5,  # 设置最大深度
  learn_rate = 0.1,  # 学习率
  seed = 1234
)

# 查看模型摘要
print(gbm_model)
best_model <- gbm_model

# 获取模型性能
perf_train <- h2o.performance(best_model, train = TRUE)  # 训练集性能
perf_test <- h2o.performance(best_model, valid = TRUE)  # 测试集性能

# 获取 MSE 和 R²
train_mse <- h2o.mse(perf_train)
train_r2 <- h2o.r2(perf_train)
test_mse <- h2o.mse(perf_test)
test_r2 <- h2o.r2(perf_test)

cat("训练集 MSE:", train_mse, "\n")
cat("训练集 R²:", train_r2, "\n")
cat("测试集 MSE:", test_mse, "\n")
cat("测试集 R²:", test_r2, "\n")

# 初始化结果存储列表
results <- list()

# 假设最佳模型已选定为 best_model，并且 data 为原始数据集
set.seed(1234)  # 设置随机种子
train_ratio <- 0.85  # 训练集比例

for (i in 1:30) {
  # 随机划分训练集和测试集
  train_idx <- sample(1:nrow(data), size = floor(train_ratio * nrow(data)))
  train_data <- as.h2o(data[train_idx, ])
  test_data <- as.h2o(data[-train_idx, ])
  
  # 训练 GBM 模型
  gbm_model <- h2o.gbm(
    x = predictors,
    y = target,
    training_frame = train_data,
    validation_frame = test_data,
    ntrees = 100,
    max_depth = 5,
    learn_rate = 0.1,
    seed = 1234
  )
  
  # 训练集性能
  train_perf <- h2o.performance(gbm_model, train_data)
  train_r2 <- h2o.r2(train_perf)
  train_mse <- h2o.mse(train_perf)
  
  # 测试集性能
  test_perf <- h2o.performance(gbm_model, test_data)
  test_r2 <- h2o.r2(test_perf)
  test_mse <- h2o.mse(test_perf)
  
  # 保存每次的结果
  results[[i]] <- data.frame(
    Iteration = i,
    Train_R2 = train_r2,
    Train_MSE = train_mse,
    Test_R2 = test_r2,
    Test_MSE = test_mse,
    R2_Diff = train_r2 - test_r2
  )
}

# 合并结果为一个数据框
results_df <- do.call(rbind, results)

# 计算平均值并打印
cat("平均训练集 R²:", mean(results_df$Train_R2), "\n")
cat("平均测试集 R²:", mean(results_df$Test_R2), "\n")
cat("平均训练集 MSE:", mean(results_df$Train_MSE), "\n")
cat("平均测试集 MSE:", mean(results_df$Test_MSE), "\n")

# 保存结果到 Excel 文件
library(writexl)
library(dplyr)
write_xlsx(results_df, "Model_Stability_Results_gbm.xlsx")