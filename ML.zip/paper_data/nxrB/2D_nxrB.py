import h2o
from h2o.automl import H2OAutoML
import pandas as pd
import matplotlib.pyplot as plt
from pdpbox import pdp

# 初始化 H2O
h2o.init(port=54322)

# 加载数据
data = pd.read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")
data_h2o = h2o.H2OFrame(data)

# 定义目标变量和特征
target = "nxrB"
predictors = ['NH3_N', 'NO3_N', 'NO2_N', 'TN', 'CODcr', 'PO4', 'TP',
              'TOC', 'COND', 'TDS', 'ORP', 'pH', 'Temp', 'DO', 'Chl_a']

# 划分数据集
train, test = data_h2o.split_frame(ratios=[0.85], seed=1234)

# 运行 H2O AutoML
aml = H2OAutoML(max_models=10, seed=1234,
                exclude_algos=["DeepLearning", "StackedEnsemble", "XGBoost", "GBM", "GLM"])
aml.train(x=predictors, y=target, training_frame=train, validation_frame=test)

# 获取最优模型
best_model = aml.leader

# 将数据转换为Pandas DataFrame用于pdpbox
data_pd = data_h2o.as_data_frame()

# 创建模型包装器
class H2OModelWrapper:
    def __init__(self, model):
        self.model = model

    def predict(self, X):
        if isinstance(X, pd.DataFrame):
            X = h2o.H2OFrame(X)
        return self.model.predict(X).as_data_frame().values.flatten()

# 创建包装器实例
wrapped_model = H2OModelWrapper(best_model)

# 二维部分依赖图
features = ['PO4', 'NH3_N']
pdp_interact = pdp.pdp_interact(
    model=wrapped_model,
    dataset=data_pd,
    model_features=predictors,
    features=features
)

# 绘制图形
fig, axes = pdp.pdp_interact_plot(
    pdp_interact_out=pdp_interact,
    feature_names=features,
    plot_type='contour',
    x_quantile=True,
    plot_pdp=True,
    figsize=(10, 12)
)

plt.title('')
plt.tight_layout()

# 保存为两种格式
plt.savefig('2d_nxrB_PO4_NH3_N.png', dpi=300, bbox_inches='tight')
plt.savefig('2d_nxrB_PO4_NH3_N.pdf', bbox_inches='tight')

plt.show()

# 关闭H2O集群
h2o.cluster().shutdown()