setwd("E:\\Rdoc\\paper_data")
# 设置工作目录
# 加载必要的库
library(corrplot)
library(readxl)
# 读取数据
data<- read_excel("E:\\Rdoc\\paper_data\\imputed_data.xlsx")

# 计算相关矩阵和p值矩阵
M <- cor(data, method = "pearson")
testRes <- cor.mtest(data, conf.level = 0.95)





pdf("hotplot2.pdf", width = 10, height = 10)

# 定义颜色范围，红色表示正相关，蓝色表示负相关
# 使用colorRampPalette生成颜色渐变，确保较低相关性不呈现特别浅的颜色
col <- colorRampPalette(c("blue4", "white", "red4"))(200)

# 绘制相关性图
corrplot(M, method = "number", type = "lower",
         tl.pos = "lt", tl.col = "black",
         col = col, number.cex = 0.7)  # 减小数字的字号

corrplot(M, type = "upper", add = TRUE, method = "color",
         tl.pos = "n", diag = FALSE, cl.pos = "n",
         p.mat = testRes$p, sig.level = c(0.001, 0.01, 0.05),
         pch.cex =1.5, insig = "label_sig",
         col = col)

dev.off()




# 生成 PDF 文件
pdf("hotplot.pdf", width = 10, height = 10)

# 定义颜色范围，红色表示正相关，蓝色表示负相关
col <- colorRampPalette(c("blue", "white", "red"))(200)

# 绘制相关性图
corrplot(corr = M, p.mat = testRes$p, type = "upper",
         tl.pos = "lt", tl.col = "black",
         insig = "label_sig", sig.level = c(.01, .05),
         pch.cex = 1, pch.col = "black", order = "original",
         col = col)

# 添加下半部分的图
corrplot(corr = M, type = "lower", add = TRUE, method = "number",
         tl.pos = "n", tl.col = "black", tl.cex = 1.2,
         col = "black", diag = FALSE, cl.pos = "n", pch.col = "black",
         number.cex = 0.8, order = "original")

# 关闭 PDF 输出设备
dev.off()





















# 设置工作目录
setwd("E:\\Rdoc\\paper_data")

# 加载必要的库
library(corrplot)
library(readxl)

# 读取数据
data <- read_excel("imputed_data.xlsx")

# 提取第 1-15 列和第 16-25 列
group1 <- data[, 1:15]
group2 <- data[, 16:25]

# 计算两个子数据框之间的相关性矩阵
# 使用 cor 函数计算 group1 和 group2 之间的相关性
M <- cor(group1, group2, method = "pearson")

# 定义颜色范围，红色表示正相关，蓝色表示负相关
# 使用 colorRampPalette 生成颜色渐变
col <- colorRampPalette(c("blue4", "white", "red4"))(200)

# 绘制相关性图
pdf("corrplot_group1_vs_group2.pdf", width = 10, height = 10)
corrplot(M, method = "number", type = "full",
         tl.pos = "lt", tl.col = "black",
         col = col, number.cex = 0.8)  # 减小数字的字号
dev.off()


















# 设置工作目录
setwd("E:\\Rdoc\\paper_data")

# 加载必要的库
library(corrplot)
library(readxl)

# 读取数据
data <- read_excel("imputed_data.xlsx")

# 提取第 1-15 列和第 16-25 列
group1 <- data[, 1:15]
group2 <- data[, 16:25]

# 计算两个子数据框之间的相关性矩阵
# 使用 cor 函数计算 group1 和 group2 之间的相关性
M <- cor(group1, group2, method = "pearson")

# 定义颜色范围，红色表示正相关，蓝色表示负相关
# 使用 colorRampPalette 生成颜色渐变
col <- colorRampPalette(c("blue4", "white", "red4"))(200)

# 计算显著性 p 值矩阵
# 使用 cor.mtest 函数计算 p 值
p.mat <- cor.mtest(cbind(group1, group2), conf.level = 0.95)$p
p.mat <- p.mat[1:15, 16:25]  # 提取 group1 和 group2 之间的 p 值
pdf("r.pdf", width = 10, height = 10)
# 绘制相关性图
corrplot(M, method = "color", type = "full",
         tl.pos = "lt", tl.col = "black",
         col = col, number.cex = 0.8,  # 减小数字的字号
         p.mat = p.mat, sig.level = c(0.001, 0.01, 0.05),  # 添加显著性标记
         insig = "label_sig",  # 在不显著的位置显示星号
         diag = FALSE)  # 不显示对角线
dev.off()


















# 设置工作目录
setwd("E:\\Rdoc\\paper_data")

# 加载必要的库
library(corrplot)
library(readxl)

# 读取数据
data <- read_excel("imputed_data.xlsx")

# 提取第 1-15 列和第 16-25 列
group1 <- data[, 1:15]
group2 <- data[, 16:25]

# 计算相关性矩阵
M <- cor(group1, group2, method = "pearson")

# 定义颜色范围（蓝色负相关，白色中性，红色正相关）
col <- colorRampPalette(c("blue4", "white", "red4"))(200)

# 计算显著性 p 值矩阵
p.mat <- cor.mtest(cbind(group1, group2), conf.level = 0.95)$p
p.mat <- p.mat[1:15, 16:25]  # 提取 group1 和 group2 之间的 p 值

# 设置 PDF 输出
pdf("r.pdf", width = 10, height = 10)

# 1. 先绘制色块（确保是方块）
corrplot(M,
         method = "color",  # 仅绘制色块（方块）
         type = "full",
         col = col,
         tl.col = "black",
         tl.cex = 1.2,
         cl.cex = 1.2,
         diag = FALSE,
         addgrid.col = "gray90")  # 网格线颜色

# 2. 叠加相关性数值（黑色，居中）
corrplot(M,
         method = "number",  # 显示数值
         number.cex = 0.8,  # 数值大小
         number.digits = 2,  # 保留2位小数
         number.font = 2,   # 粗体
         col = "black",     # 数值颜色
         bg = NA,           # 透明背景（避免覆盖色块）
         add = TRUE,        # 叠加在色块上
         type = "full",
         diag = FALSE,
         tl.pos = "n",      # 不重复标签
         cl.pos = "n")      # 不重复图例

# 3. 叠加显著性星号（数值下方）
corrplot(M,
         method = "pie",    # 用"pie"方法仅显示星号（不改变色块）
         p.mat = p.mat,
         sig.level = c(0.001, 0.01, 0.05),
         insig = "label_sig",  # 显示显著性标记
         pch.cex = 0.9,     # 星号大小
         pch.col = "black",  # 星号颜色
         add = TRUE,         # 叠加
         type = "full",
         diag = FALSE,
         tl.pos = "n",
         cl.pos = "n")

# 关闭 PDF 设备
dev.off()