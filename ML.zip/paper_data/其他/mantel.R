# 设置工作目录
setwd('E:\\Rdoc\\paper_data')

# 加载必要的包
library(readxl)
library(vegan)
library(dplyr)
library(ggplot2)
library(reshape2)
library(RColorBrewer)

# 读取 Excel 文件
data <- read_excel("imputed_data.xlsx", sheet = 1)

# 查看数据结构
str(data)

# 假设前几列是第一组变量，后几列是第二组变量
# 例如，前 15 列是第一组，后 10 列是第二组
group1 <- data[, 1:15]
group2 <- data[, 16:25]

# 计算距离矩阵
dist_matrix1 <- vegdist(group1, method = "euclidean")
dist_matrix2 <- vegdist(group2, method = "euclidean")

# 进行 Mantel 检验
mantel_result <- mantel(dist_matrix1, dist_matrix2, method = "pearson", permutations = 999)

# 查看结果
print(mantel_result)

# 把 dist_matrix1 拆分为 4 个类别的矩阵
# 假设每个类别包含等数量的列
n <- ncol(group1)
group_sizes <- c(5, 5, 5)  # 前 3 个类别各 5 列

# 生成分割索引
group1_split <- rep(1:length(group_sizes), group_sizes)

# 对每个类别矩阵与 dist_matrix2 进行 Mantel 检验
mantel_results <- lapply(group1_split, function(sub_group) {
  sub_dist_matrix <- vegdist(sub_group, method = "euclidean")
  mantel(sub_dist_matrix, dist_matrix2, method = "pearson", permutations = 999)
})

# 将 Mantel 检验结果整理为数据框
mantel_df <- do.call(rbind, lapply(seq_along(mantel_results), function(i) {
  data.frame(
    Group = i,
    r = mantel_results[[i]]$mantel.r,
    p = mantel_results[[i]]$signif
  )
}))

# 把连续型变量划分为区间，转换为因子型变量
mantel_df <- mantel_df %>%
  mutate(rd = cut(r, breaks = c(-Inf, 0.2, 0.4, Inf),
                  labels = c("< 0.2", "0.2 - 0.4", ">= 0.4")),
         pd = cut(p, breaks = c(-Inf, 0.01, 0.05, Inf),
                  labels = c("< 0.01", "0.01 - 0.05", ">= 0.05")))

# 相关性分析
cor_matrix <- cor(group1, use = "complete.obs", method = "pearson")

# 绘制热图
# 注意：qcorrplot 不是标准函数，这里假设你有一个类似的函数或自定义函数
# 如果没有，可以使用 corrplot 包的 corrplot 函数
library(corrplot)
corrplot(cor_matrix, type = "lower", diag = FALSE, 
         col = RColorBrewer::brewer.pal(11, "PuOr"))

# 添加网络线和显著性标记
# 注意：geom_couple 和 geom_mark 不是标准函数，这里假设你有类似的函数或自定义函数
# 如果没有，可以使用 ggplot2 的其他函数来实现类似效果
# 以下代码仅作为示例，可能需要根据实际情况调整
ggplot(mantel_df, aes(x = Group, y = r, color = pd, size = rd)) +
  geom_point() +
  geom_line() +
  scale_color_manual(values = c("red", "orange", "green")) +
  scale_size_manual(values = c(1, 2, 3)) +
  theme_minimal() +
  theme(
    text = element_text(size = 12, family = "serif"),
    plot.title = element_text(size = 12, colour = "pink", hjust = 0.5),
    legend.title = element_text(color = "black", size = 12),
    legend.text = element_text(color = "black", size = 12),
    axis.text.y = element_text(size = 12, color = "black", vjust = 0.5, hjust = 1, angle = 0),
    axis.text.x = element_text(size = 12, color = "black", vjust = 0.5, hjust = 0.5, angle = 45)
  )


dim(group1)
dim(group2)
         