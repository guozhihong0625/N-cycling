# 安装和加载包
if (!require("plspm")) install.packages("plspm")
if (!require("ggplot2")) install.packages("ggplot2")
if (!require("gridExtra")) install.packages("gridExtra")

library(plspm)
library(ggplot2)
library(gridExtra)

# 加载数据
data(russett)

# 定义模型结构
blocks <- list(
  Agriculture = c("gini", "farm", "rent"),
  Industry = c("gnpr", "labo"),
  Political = c("inst", "ecks", "death")
)

path_matrix <- rbind(
  Agriculture = c(0, 0, 0),
  Industry = c(1, 0, 0),
  Political = c(1, 1, 0)
)

modes <- rep("A", length(blocks))
names(modes) <- names(blocks)

# 运行PLS-PM分析
pls_result <- plspm(russett, path_matrix, blocks, modes = modes, boot.val = TRUE, br = 200)

# 查看结果
summary(pls_result)

# 绘制路径系数图
path_coefs <- pls_result$path_coefs
path_df <- data.frame(
  from = rep(rownames(path_coefs), each = ncol(path_coefs)),
  to = rep(colnames(path_coefs), times = nrow(path_coefs)),
  coef = as.vector(path_coefs)
)
path_df <- path_df[path_df$coef != 0, ]

p1 <- ggplot(path_df, aes(x = from, y = to, label = round(coef, 2))) +
  geom_point(aes(size = abs(coef), color = coef > 0), alpha = 0.7) +
  geom_text(vjust = -1.5) +
  geom_segment(aes(xend = to, yend = from, size = abs(coef)), 
               arrow = arrow(length = unit(0.2, "cm")), 
               show.legend = FALSE) +
  scale_size_continuous(range = c(2, 8)) +
  scale_color_manual(values = c("red", "blue")) +
  labs(title = "PLS-PM Path Coefficients", x = "From", y = "To") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# 绘制载荷图
loadings <- pls_result$outer_model
p2 <- ggplot(loadings, aes(x = name, y = loading, fill = block)) +
  geom_bar(stat = "identity") +
  geom_hline(yintercept = 0.7, linetype = "dashed", color = "red") +
  facet_wrap(~block, scales = "free_x") +
  labs(title = "Loadings for Each Latent Variable", y = "Loading", x = "Indicator") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# 绘制R平方图
r_squared <- pls_result$inner_summary[, "R2", drop = FALSE]
p3 <- ggplot(as.data.frame(r_squared), aes(x = rownames(r_squared), y = R2)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(title = "R-squared for Endogenous Latent Variables", 
       x = "Latent Variable", y = "R-squared") +
  ylim(0, 1) +
  theme_minimal()

# 显示所有图形
grid.arrange(p1, p2, p3, ncol = 2)

# 使用内置函数绘制综合路径图
plot(pls_result)
