# 设置工作目录
setwd("E:\\Rdoc\\paper_data\\其他")

# 加载必要的库
library(corrplot)
library(readxl)

# 读取数据
data <- read_excel("mmm.xlsx")

# 提取第 1-15 列和第 16-77 列
group1 <- data[, 1:15]
group2 <- data[, 16:77]

# 检查是否有缺失值
if (any(is.na(group1)) || any(is.na(group2))) {
  stop("数据中存在缺失值，请先处理缺失值。")
}

# 计算相关性矩阵
M <- cor(group1, group2, method = "pearson", use = "complete.obs")

# 定义颜色范围（蓝色负相关，白色中性，红色正相关）
col <- colorRampPalette(c("blue4", "white", "red4"))(200)

# 计算显著性 p 值矩阵
p.mat <- cor.mtest(cbind(group1, group2), conf.level = 0.95)$p
p.mat <- p.mat[1:15, 16:77]  # 提取 group1 和 group2 之间的 p 值

# 设置 PDF 输出
pdf("correlation_heatmap.pdf", width = 10, height = 10)

# 绘制色块（颜色深浅表示相关性大小）
corrplot(M,
         method = "color",  # 使用颜色深浅表示相关性大小
         type = "full",
         col = col,
         tl.col = "black",
         tl.cex = 0.6,      # 缩小标签字体大小
         cl.cex = 1.2,
         diag = FALSE,
         addgrid.col = "gray90")  # 网格线颜色

# 叠加相关性数值（黑色，居中）
corrplot(M,
         method = "number",  # 显示数值
         number.cex = 0.8,  # 数值大小
         number.digits = 2,  # 保留2位小数
         number.font = 2,   # 粗体
         col = "black",     # 数值颜色
         bg = NA,           # 透明背景（避免覆盖色块）
         add = TRUE,        # 叠加在色块上
         type = "full",
         diag = FALSE,
         tl.pos = "n",      # 不重复标签
         cl.pos = "n")      # 不重复图例

# 叠加显著性星号（数值下方）
corrplot(M,
         method = "color",  # 使用颜色深浅表示相关性大小
         p.mat = p.mat,
         sig.level = c(0.001, 0.01, 0.05),
         insig = "label_sig",  # 显示显著性标记
         pch.cex = 0.9,     # 星号大小
         pch.col = "black",  # 星号颜色
         add = TRUE,         # 叠加
         type = "full",
         diag = FALSE,
         tl.pos = "n",
         cl.pos = "n")

# 关闭 PDF 设备
dev.off()