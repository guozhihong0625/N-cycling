library(readxl)
# 使用基础绘图系统
data <- read_xlsx("基因丰度.xlsx", sheet = "all_genes")
library(tidyr)

# 转换数据（假设数据框名为 data）
data_long <- pivot_longer(
  data,
  cols = -Gene,                  # 除 Gene 列外的所有列
  names_to = "Sample",           # 新列名（样本名）
  values_to = "Abundance"        # 新列名（表达量）
)

# 查看转换后的数据
head(data_long)

library(ggplot2)

# 按基因分组
p <-ggplot(data_long, aes(x = Gene, y = Abundance)) +
  geom_boxplot(fill = "lightblue") +
  labs(title = "基因表达丰度分布") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))  # 旋转 x 轴标签

ggsave("gene_abundance_boxplot.pdf", plot = p, width = 10, height = 6, units = "in")











library(readxl)
library(tidyr)
library(ggplot2)
library(dplyr)  # 用于数据汇总

# 1. 读取数据
data <- read_xlsx("基因丰度.xlsx", sheet = "all_genes")

# 2. 转换成长格式
data_long <- pivot_longer(
  data,
  cols = -Gene,
  names_to = "Sample",
  values_to = "Abundance"
)

# 3. 计算每个基因的总丰度
gene_totals <- data_long %>%
  group_by(Gene) %>%
  summarise(Total_Abundance = sum(Abundance, na.rm = TRUE)) %>%
  arrange(desc(Total_Abundance))  # 按总丰度降序排列

# 查看计算结果
head(gene_totals)

# 4. 绘制气泡图
ggplot(gene_totals, aes(x = reorder(Gene, -Total_Abundance), y = Total_Abundance)) +
  geom_point(aes(size = Total_Abundance, color = Total_Abundance), alpha = 0.7) +
  scale_size_continuous(range = c(3, 10)) +  # 调整气泡大小范围
  scale_color_gradient(low = "lightblue", high = "darkblue") +  # 颜色渐变
  labs(title = "基因表达总丰度气泡图",
       x = "Gene",
       y = "Total Abundance",
       size = "Total Abundance",
       color = "Total Abundance") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = "right")

# 5. 保存图形
ggsave("gene_total_abundance_bubble.pdf", width = 12, height = 8, units = "in")




library(ggplot2)
library(scales)

# 示例数据
gene_data <- data.frame(
  Gene = c("amoA_B", "amoA_C", "amoB_B", "amoC_B", "ansB", "asnB", "gdh_K00260", "gdh_K00261",
           "gdh_K00262", "gdh_K15371", "glnA", "glsA", "gs_K00264", "gs_K00265", "gs_K00266",
           "gs_K00284", "hao", "hcp", "hzo", "hzsA", "nao", "napA", "napB", "napC", "narB",
           "narC", "narG", "narH", "narI", "narJ", "narV", "narW", "narY", "narZ", "nasA",
           "nasB", "nifD", "nifH", "nifK", "nifW", "nirA", "nirB", "nirD", "nirK", "nirS",
           "nmo", "norB", "norC", "nosZ", "NR", "nrfA", "nrfB", "nrfC", "nrfD", "nxrA",
           "nxrB", "pmoA", "pmoB", "pmoC", "ureA", "ureB", "ureC"),
  Value = c(0.072684987, 0.014389539, 0.041938689, 0.111485156, 0.268438136, 1.497806361,
            0.013019452, 1.754350222, 2.394146094, 0.566518081, 11.00905844, 0.679734535,
            0.015000767, 4.559448072, 4.992537412, 0.855986912, 0.055015302, 0.317673415,
            0.004677017, 0.004305775, 0.005335856, 0.763761141, 0.763761141, 0.287525653,
            0.303999047, 0.018265528, 3.134241347, 2.844998267, 1.019195427, 0.935004424,
            0.374643027, 0.001944245, 0.610413418, 1.79475326, 1.362668496, 0.006463948,
            0.453042534, 1.542600773, 0.275351156, 0.071044498, 0.255535444, 3.154484567,
            1.471827012, 0.66739962, 2.671008833, 7.303074921, 2.076718269, 0.82359442,
            2.352948633, 0.01229289, 0.10099141, 0.039069697, 0.480309788, 0.034814221,
            0.00023733, 0.153517372, 0.061236002, 0.029537779, 0.068455205, 3.382380849,
            2.610891913, 3.903208745)
)

# 创建8x8网格坐标（保持原始顺序）
grid_size <- 8
gene_data <- gene_data %>%
  mutate(
    row = floor((row_number() - 1) / grid_size) + 1,
    col = ((row_number() - 1) %% grid_size) + 1
  )

# 绘制气泡图
ggplot(gene_data, aes(x = col, y = row)) +
  # 添加基因名称（左侧）
  geom_text(aes(label = Gene), hjust = 1.1, size = 3, x = 0.5) +
  # 添加气泡（右侧）
  geom_point(aes(size = Value, color = Value), 
             position = position_nudge(x = 0.5), alpha = 0.8) +
  # 调整气泡大小和颜色
  scale_size_continuous(
    name = "Value",
    range = c(2, 12),
    breaks = pretty_breaks(5)
  ) +
  scale_color_gradient(
    name = "Value",
    low = "lightblue", 
    high = "darkblue",
    breaks = pretty_breaks(5)
  ) +
  # 设置坐标轴范围
  scale_x_continuous(limits = c(0, grid_size + 1), expand = c(0, 0)) +
  scale_y_reverse(limits = c(grid_size + 0.5, 0.5), expand = c(0, 0)) +
  # 添加标题和主题设置
  labs(title = "基因丰度分布 (8×8网格)") +
  theme_void() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    legend.position = "right",
    plot.margin = margin(20, 20, 20, 40)  # 增加左边距给基因名称留空间
  )

# 保存图形
ggsave("gene_abundance_8x8_original_order.pdf", width = 12, height = 10, units = "in")















library(ggplot2)
library(scales)
library(dplyr)

# 示例数据
gene_data <- data.frame(
  Gene = c("amoA_B", "amoA_C", "amoB_B", "amoC_B", "ansB", "asnB", "gdh_K00260", "gdh_K00261",
           "gdh_K00262", "gdh_K15371", "glnA", "glsA", "gs_K00264", "gs_K00265", "gs_K00266",
           "gs_K00284", "hao", "hcp", "hzo", "hzsA", "nao", "napA", "napB", "napC", "narB",
           "narC", "narG", "narH", "narI", "narJ", "narV", "narW", "narY", "narZ", "nasA",
           "nasB", "nifD", "nifH", "nifK", "nifW", "nirA", "nirB", "nirD", "nirK", "nirS",
           "nmo", "norB", "norC", "nosZ", "NR", "nrfA", "nrfB", "nrfC", "nrfD", "nxrA",
           "nxrB", "pmoA", "pmoB", "pmoC", "ureA", "ureB", "ureC"),
  Value = c(0.072684987, 0.014389539, 0.041938689, 0.111485156, 0.268438136, 1.497806361,
            0.013019452, 1.754350222, 2.394146094, 0.566518081, 11.00905844, 0.679734535,
            0.015000767, 4.559448072, 4.992537412, 0.855986912, 0.055015302, 0.317673415,
            0.004677017, 0.004305775, 0.005335856, 0.763761141, 0.763761141, 0.287525653,
            0.303999047, 0.018265528, 3.134241347, 2.844998267, 1.019195427, 0.935004424,
            0.374643027, 0.001944245, 0.610413418, 1.79475326, 1.362668496, 0.006463948,
            0.453042534, 1.542600773, 0.275351156, 0.071044498, 0.255535444, 3.154484567,
            1.471827012, 0.66739962, 2.671008833, 7.303074921, 2.076718269, 0.82359442,
            2.352948633, 0.01229289, 0.10099141, 0.039069697, 0.480309788, 0.034814221,
            0.00023733, 0.153517372, 0.061236002, 0.029537779, 0.068455205, 3.382380849,
            2.610891913, 3.903208745)
)

# 创建8x8网格坐标（保持原始顺序）
grid_size <- 8
gene_data <- gene_data %>%
  mutate(
    row = floor((row_number() - 1) / grid_size) + 1,
    col = ((row_number() - 1) %% grid_size) + 1
  )

# 绘制气泡图
ggplot(gene_data, aes(x = col, y = row)) +
  # 添加气泡
  geom_point(aes(size = Value, color = Value), alpha = 0.8) +
  # 添加基因名称（在气泡下方）
  geom_text(aes(label = Gene), vjust = 2.5, size = 2.5, check_overlap = TRUE) +
  # 添加数值标签（在气泡上方）
  geom_text(aes(label = sprintf("%.2f", Value)), vjust = -1.5, size = 2.5, color = "black") +
  # 调整气泡大小和颜色
  scale_size_continuous(
    name = "Value",
    range = c(3, 12),
    breaks = pretty_breaks(5)
  ) +
  scale_color_gradient(
    name = "Value",
    low = "lightblue", 
    high = "darkblue",
    breaks = pretty_breaks(5)
  ) +
  # 设置坐标轴范围
  scale_x_continuous(limits = c(0.5, grid_size + 0.5), expand = c(0, 0)) +
  scale_y_reverse(limits = c(grid_size + 0.5, 0.5), expand = c(0, 0)) +
  # 添加标题和主题设置
  labs(title = "基因丰度分布 (8×8网格)") +
  theme_minimal() +
  theme(
    panel.grid = element_blank(),
    axis.text = element_blank(),
    axis.title = element_blank(),
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    legend.position = "right"
  )

# 保存图形
ggsave("gene_abundance_8x8_label_below.pdf", width = 12, height = 10, units = "in")


