# 设置工作目录
setwd('E:\\Rdoc\\paper_data\\其他')
library(readxl)
library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)  # 新增 patchwork 包用于组合图形

# 读取数据
df <- read_excel("环境因子.xls", sheet = "Sheet1")

# 指标列名（全部）
vars <- c("NH3-N", "NO3-N", "NO2-N", "TN", "CODcr", "PO4", "TP", "TOC",
          "COND", "TDS", "ORP", "pH", "Temp", "DO", "Chl-a")

# 转长表
df_long <- df %>%
  pivot_longer(
    cols = all_of(vars),
    names_to = "variable",
    values_to = "value"
  ) %>%
  mutate(
    value = as.numeric(value),
    Plant = factor(Plant),                          # 假定为 GBD / QH
    site  = factor(site, levels = c("UP", "OUT", "DOWN")),
    time  = factor(time, levels = c(201511, 201603, 201609, 201809, 201812, 201903))
  )

# 三组变量
group_list <- list(
  group1 = c("NH3-N", "NO3-N", "NO2-N", "TN", "CODcr"),
  group2 = c("PO4", "TP", "TOC", "COND", "TDS"),
  group3 = c("ORP", "pH", "Temp", "DO", "Chl-a")
)

# 创建三个独立的图并存储
plot_list <- list()

for (g in seq_along(group_list)) {
  
  vars_g <- group_list[[g]]
  plot_dat <- df_long %>% filter(variable %in% vars_g)
  
  p <- ggplot() +
    # 散点：按 site 上色
    geom_point(
      data = plot_dat,
      aes(x = time, y = value, color = site),
      alpha = 0.8, size = 2
    ) +
    # loess 平滑线：用数值 time 拟合
    geom_smooth(
      data = plot_dat,
      aes(x = as.numeric(time), y = value),
      method = "loess",
      span = 2,
      se = FALSE,
      linewidth = 1,
      color = "#FCD28C",
      inherit.aes = FALSE
    ) +
    # Plant 上下、变量左右
    facet_grid(variable ~ Plant, scales = "free_y") +
    
    # 三种科研配色（UP / OUT / DOWN）
    scale_color_manual(values = c(
      "UP"   = "#EB6368",
      "OUT"  = "#32ADD0",
      "DOWN" = "#33A02C"
    )) +
    
    theme_bw() +
    labs(
      x = "Time",
      y = "",
      color = "Site",
      title = paste("Group", g)
    ) +
    theme(
      strip.text = element_text(size = 8),
      axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
      axis.text.y = element_text(size = 7),
      plot.title = element_text(hjust = 0.5, face = "bold", size = 10),
      panel.grid = element_blank(),
      legend.position = "none"  # 所有子图都不显示图例
    )
  
  plot_list[[g]] <- p
}

# 使用 patchwork 组合三个图，并将图例放在最右侧
combined_plot <- plot_list[[1]] + plot_list[[2]] + plot_list[[3]] + 
  plot_layout(nrow = 1, guides = 'collect') &  # 收集所有图例
  theme(plot.margin = margin(5, 5, 5, 5),
        legend.position = "right")  # 图例放在右侧

# 添加总标题（可选）
combined_plot <- combined_plot + 
  plot_annotation(theme = theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 12)))

# 显示组合图
print(combined_plot)

# 保存组合图
ggsave(filename = "Env_facet_combined.pdf",
       plot = combined_plot, width = 12, height = 10)  # 增加宽度以容纳图例