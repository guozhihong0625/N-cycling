# Load required libraries
library(readxl)
library(ggplot2)
library(RColorBrewer)

# Read Excel file
file_path <- "环境因子.xls"  # Make sure the file path is correct
data <- read_excel(file_path)

# Calculate non-empty ratio for each column
non_empty_ratio <- sapply(data, function(col) {
  1 - sum(is.na(col)) / length(col)
})

# Get first row as column labels
column_labels <- as.character(data[1, ])

# Create data frame for plotting
plot_data <- data.frame(
  Column = names(non_empty_ratio),
  Label = column_labels,
  NonEmptyRatio = non_empty_ratio
)

# Generate unique colors for each variable
num_vars <- nrow(plot_data)
colors <- brewer.pal(min(num_vars, 12), "Paired")
if(num_vars > 12) {
  colors <- colorRampPalette(colors)(num_vars)
}

# Create the plot object with extra large axis text
p <- ggplot(plot_data, aes(x = reorder(Column, NonEmptyRatio), y = NonEmptyRatio, fill = Column)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = colors) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 24),  # 特大x轴刻度标签
    axis.text.y = element_text(size = 24),                         # 特大y轴刻度标签
    axis.title.x = element_text(size = 36, margin = margin(t = 20)), # 特大x轴标题+上边距
    axis.title.y = element_text(size = 36, margin = margin(r = 20)), # 特大y轴标题+右边距
    plot.margin = margin(1, 1, 1, 1, "cm")  # 增加整体边距
  ) +
  labs(title = "Non-empty Value Ratio by Column", 
       x = "Column Name", 
       y = "Non-empty Ratio", 
       fill = "Variables") +
  theme_minimal() +
  guides(fill = guide_legend(ncol = 1))

# Save as PDF with larger dimensions
ggsave("non_empty_ratio_plot.pdf", 
       plot = p,
       width = 8,        # 大幅增加宽度
       height = 6,       # 大幅增加高度
       units = "in",      
       device = "pdf")    

# Display the plot
print(p)