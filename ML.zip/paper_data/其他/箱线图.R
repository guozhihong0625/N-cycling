
#-----------------1----------------
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)

# 1. 读取Excel数据
data <- read_excel("boxplot_data.xlsx", sheet = "all_genes")

# 2. 转换为长格式
data_long <- data %>%
  pivot_longer(cols = -Gene, names_to = "Sample", values_to = "Expression") %>%
  filter(!is.na(Expression)) %>%  # 移除缺失值
  mutate(logExpr = log10(Expression + 0.001))  # 预先计算对数表达值

# 3. 将基因按Z-A降序排列
data_long <- data_long %>%
  mutate(Gene = factor(Gene, levels = sort(unique(Gene), decreasing = TRUE)))

# 4. 绘制横向箱线图（Z-A顺序）
ggplot(data_long, aes(y = Gene, x = Expression + 0.001)) +  # 注意x和y交换
  geom_boxplot(
    aes(fill = logExpr),  # 使用预先计算的对数值填充颜色
    outlier.shape = 21,
    outlier.size = 2,
    outlier.fill = "#e41a1c",
    outlier.alpha = 0.6,
    notch = FALSE,
    alpha = 0.8,
    orientation = "y"  # 指定箱线图横向
  ) +
  scale_fill_gradient(
    low = "#91bfdb", 
    high = "#4575b4",
    name = "Log10(Expression)"
  ) +
  scale_x_log10(
    breaks = c(0.001, 0.01, 0.1, 1, 10),
    labels = c("0", "0.01", "0.1", "1", "10")
  ) +
  labs(
    title = "Gene Expression Abundance Distribution",
    subtitle = "Boxplot across all samples (Z-A order)",
    y = "Gene Name",  # y轴现在是基因名
    x = "Expression Abundance (log10 scale)"  # x轴现在是表达量
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.y = element_text(  # 修改y轴文本（现在是基因名）
      hjust = 1,
      face = "italic"
    ),
    axis.text.x = element_text(  # x轴文本（现在是表达量）
      angle = 0,
      hjust = 0.5
    ),
    plot.title = element_text(
      hjust = 0.5,
      size = 16,
      face = "bold"
    ),
    plot.subtitle = element_text(
      hjust = 0.5,
      size = 12,
      color = "gray40"
    ),
    legend.position = "right",
    panel.grid.major.y = element_blank(),  # 修改为y轴网格线
    panel.grid.minor.x = element_blank()   # 修改为x轴网格线
  ) 
# 注意：移除了coord_flip()，改用orientation="y"实现横向

# 5. 保存图形
ggsave("gene_expression_horizontal_boxplot_Z-A.pdf", 
       width = 6,  # 调整宽度和高度
       height = 12,
       units = "in",
       dpi = 300)
















#-----------------2----------------
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)

# 1. 读取Excel数据
data <- read_excel("boxplot_data.xlsx", sheet = "all_genes")

# 2. 转换为长格式
data_long <- data %>%
  pivot_longer(cols = -Gene, names_to = "Sample", values_to = "Expression") %>%
  filter(!is.na(Expression)) %>%
  mutate(logExpr = log10(Expression + 0.001))

# 3. 将基因按A-Z升序排列（x轴顺序）
data_long <- data_long %>%
  mutate(Gene = factor(Gene, levels = sort(unique(Gene), decreasing = FALSE)))  # FALSE表示升序

# 4. 绘制竖向箱线图（A-Z顺序）
ggplot(data_long, aes(x = Gene, y = Expression + 0.001)) +
  geom_boxplot(
    aes(fill = logExpr),
    outlier.shape = 21,
    outlier.size = 2,
    outlier.fill = "#e41a1c",
    outlier.alpha = 0.6,
    notch = FALSE,
    alpha = 0.8
  ) +
  scale_fill_gradient(
    low = "#91bfdb",
    high = "#4575b4",
    name = "Log10(Expression)"
  ) +
  scale_y_log10(
    breaks = c(0.001, 0.01, 0.1, 1, 10),
    labels = c("0", "0.01", "0.1", "1", "10"),
    expand = expansion(mult = c(0.05, 0.1))  # 调整y轴上下边距
  ) +
  labs(
    title = "Gene Expression Abundance Distribution",
    subtitle = "Vertical Boxplot (A-Z Order)",  # 更新副标题
    x = "Gene Name",
    y = "Expression Abundance (log10 scale)"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(
      angle = 90,  # x轴标签90度垂直
      hjust = 1,
      vjust = 0.5,  # 垂直居中
      face = "italic",
      size = 8  # 调小字体避免重叠
    ),
    plot.title = element_text(
      hjust = 0.5,
      size = 16,
      face = "bold"
    ),
    plot.subtitle = element_text(
      hjust = 0.5,
      size = 12,
      color = "gray40"
    ),
    legend.position = "right",
    panel.grid.major.x = element_blank(),  # 隐藏垂直网格线
    panel.grid.minor.y = element_blank()
  )

# 5. 保存图形
ggsave("gene_expression_vertical_boxplot_A-Z.pdf",  # 更新文件名
       width = 12,  # 更宽的画布适应基因名
       height = 6,
       units = "in",
       dpi = 300)





















#-----------------3----------------
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)

# 1. 读取Excel数据
data <- read_excel("boxplot_data.xlsx", sheet = "all_genes")

# 2. 转换为长格式
data_long <- data %>%
  pivot_longer(cols = -Gene, names_to = "Sample", values_to = "Expression") %>%
  filter(!is.na(Expression))  # 移除缺失值

# 3. 将基因按Z-A降序排列
data_long <- data_long %>%
  mutate(Gene = factor(Gene, levels = sort(unique(Gene), decreasing = TRUE)))

# 4. 绘制横向箱线图（Z-A顺序）
ggplot(data_long, aes(y = Gene, x = Expression)) +  # 使用原始数据
  geom_boxplot(
    outlier.shape = 21,
    outlier.size = 2,
    outlier.fill = "#e41a1c",
    outlier.alpha = 0.6,
    notch = FALSE,
    alpha = 0.8,
    orientation = "y"  # 指定箱线图横向
  ) +
  scale_x_continuous(
    name = "Expression Abundance",
    breaks = c(0, 0.1, 0.2),  # 设置横坐标刻度
    limits = c(0, 0.2)        # 设置横坐标范围
  ) +
  labs(
    title = "Gene Expression Abundance Distribution",
    subtitle = "Boxplot across all samples",
    y = "Gene Name",  # y轴现在是基因名
    x = "Expression Abundance"  # x轴现在是表达量
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.y = element_text(  # 修改y轴文本（现在是基因名）
      hjust = 1,
      face = "italic"
    ),
    axis.text.x = element_text(  # x轴文本（现在是表达量）
      angle = 0,
      hjust = 0.5
    ),
    plot.title = element_text(
      hjust = 0.5,
      size = 16,
      face = "bold"
    ),
    plot.subtitle = element_text(
      hjust = 0.5,
      size = 12,
      color = "gray40"
    ),
    legend.position = "none",  # 去掉填充颜色的图例
    panel.grid.major.y = element_blank(),  # 修改为y轴网格线
    panel.grid.minor.x = element_blank()   # 修改为x轴网格线
  ) 

# 5. 保存图形
ggsave("yh.pdf", 
       width = 6,  # 调整宽度和高度
       height = 11,
       units = "in",
       dpi = 300)









#-----------------4----------------
library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)

# 1. 读取Excel数据
data <- read_excel("boxplot_data.xlsx", sheet = "all_genes")

# 2. 转换为长格式
data_long <- data %>%
  pivot_longer(cols = -Gene, names_to = "Sample", values_to = "Expression") %>%
  filter(!is.na(Expression))  # 移除缺失值

# 3. 将基因按A-Z升序排列（x轴顺序）
data_long <- data_long %>%
  mutate(Gene = factor(Gene, levels = sort(unique(Gene), decreasing = FALSE)))  # FALSE表示升序

# 4. 绘制竖向箱线图（A-Z顺序）
ggplot(data_long, aes(x = Gene, y = Expression)) +  # 使用原始数据
  geom_boxplot(
    outlier.shape = 21,
    outlier.size = 2,
    outlier.fill = "#e41a1c",
    outlier.alpha = 0.6,
    notch = FALSE,
    alpha = 0.8
  ) +
  scale_y_continuous(  # 设置纵坐标为线性刻度
    breaks = c(0, 0.1, 0.2),  # 设置纵坐标刻度
    limits = c(0, 0.2),       # 设置纵坐标范围
    name = "Expression Abundance"
  ) +
  labs(
    title = "Gene Expression Abundance Distribution",
    subtitle = "Vertical Boxplot",  # 更新副标题
    x = "Gene Name",
    y = "Expression Abundance"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(
      angle = 90,  # x轴标签90度垂直
      hjust = 1,
      vjust = 0.5,  # 垂直居中
      face = "italic",
      size = 8  # 调小字体避免重叠
    ),
    plot.title = element_text(
      hjust = 0.5,
      size = 16,
      face = "bold"
    ),
    plot.subtitle = element_text(
      hjust = 0.5,
      size = 12,
      color = "gray40"
    ),
    legend.position = "none",  # 移除图例
    panel.grid.major.x = element_blank(),  # 隐藏垂直网格线
    panel.grid.minor.y = element_blank()
  )

# 5. 保存图形
ggsave("y_Z.pdf",  # 更新文件名
       width = 12,  # 更宽的画布适应基因名
       height = 6,
       units = "in",
       dpi = 300)
