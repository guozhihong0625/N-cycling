library(ggplot2)

# 创建数据框
df <- data.frame(
  gene = c("gdh", "glnA", "narG", "nasA", "nifH", 
           "nirB", "nirS", "norB", "nosZ", "nxrB"),
  color = c("#1F77B4", "#FF9896", "#7CA02C", "#C49C94", "#9467BD", 
            "#962728", "#0F7F7F", "#BCBD22", "#17BECF", "#FF7F0E")
)

# 生成线中间加点的图例
p <- ggplot(df, aes(x = 1, y = gene, color = gene)) +
  geom_segment(aes(x = 0.5, xend = 1.5), size = 1) +  # 线段更长
  geom_point(aes(x = 1), size =1.5, shape = 19) +      # 在线中间添加点
  scale_color_manual(values = setNames(df$color, df$gene)) +
  theme_void() +
  labs(color = "Gene Legend") +  # 修改图例标题
  theme(
    legend.position = "right",
    legend.text = element_text(size = 10),
    legend.key = element_blank()  # 移除默认的图例背景
  )

# 导出为PDF
ggsave("gene_legend.pdf", p, width = 6, height = 4, device = "pdf")