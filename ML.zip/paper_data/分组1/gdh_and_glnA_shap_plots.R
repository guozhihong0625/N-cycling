
#按字母-----------------

# 加载必要的库
library(shapper)
library(ggplot2)
library(dplyr)

# 假设你已经有了 SHAP 值，gdh 和 glnA 的 SHAP 值数据存储在 `shap_values_gdh` 和 `shap_values_glnA` 中
shap_values_gdh <- read.csv("E:\\Rdoc\\paper_data\\gdh\\variable_importance_percentage.csv")
shap_values_glnA <- read.csv("E:\\Rdoc\\paper_data\\glnA\\variable_importance_percentage.csv")
# 假设 SHAP 值数据的结构如下：数据框形式，每一列对应一个解释变量，目标变量分别是 gdh 和 glnA
# 请确保 shap_values_gdh 和 shap_values_glnA 都包含与 predictors 对应的 SHAP 值

# 合并两个目标变量的 SHAP 数据，并为每个目标变量添加标识
shap_values <- bind_rows(
  shap_values_gdh %>% mutate(target = "gdh"),
  shap_values_glnA %>% mutate(target = "glnA")
)

# 对 gdh 的 SHAP 值进行负值处理，以确保左侧为负值，右侧为正值
shap_values <- shap_values %>%
  mutate(percentage = ifelse(target == "gdh", -percentage, percentage))

# 生成PDF文件
pdf("E:\\Rdoc\\paper_data\\分组1\\gdh_and_glnA_shap_plots.pdf")  # 指定你想保存的PDF文件路径


ggplot(shap_values, aes(x = reorder(variable, percentage), y = percentage, fill = target)) +
  geom_bar(stat = "identity", position = "identity", width = 0.7) +
  coord_flip() +  # 翻转坐标轴
  labs(
    title = "SHAP Value Comparison for Target Variables",
    x = "Variable",
    y = "SHAP Value"
  ) +
  scale_x_discrete(limits = rev(levels(factor(shap_values$variable)))) +  # 逆转 x 轴顺序
  scale_fill_manual(values = c("gdh" = "#9E7EBD", "glnA" = "#87BFD6")) +  # 设置颜色
  scale_y_continuous(limits = c(-0.4, 0.4), breaks = seq(-0.4, 0.4, 0.2)) +  # 设置 y 轴范围
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.title = element_blank(),  # 去掉图例标题
        legend.position = "top")
# 关闭PDF设备
dev.off()






#按大小-------------
# 加载必要的库
library(ggplot2)
library(dplyr)

# 读取 SHAP 值数据
shap_values_gdh <- read.csv("E:\\Rdoc\\paper_data\\gdh\\variable_importance_percentage.csv")
shap_values_glnA <- read.csv("E:\\Rdoc\\paper_data\\glnA\\variable_importance_percentage.csv")

# 合并两个目标变量的 SHAP 数据，并为每个目标变量添加标识
shap_values <- bind_rows(
  shap_values_gdh %>% mutate(target = "gdh"),
  shap_values_glnA %>% mutate(target = "glnA")
)

# 计算每个变量的百分比总和，并按总和升序排序
shap_sum <- shap_values %>%
  group_by(variable) %>%
  summarise(total_percentage = sum(percentage)) %>%
  arrange(total_percentage)  # 按总和升序排列


# 重新排序 shap_values 的变量顺序
shap_values$variable <- factor(shap_values$variable, 
                               levels = shap_sum$variable)

# 对 gdh 的 SHAP 值进行负值处理，以确保左侧为负值，右侧为正值
shap_values <- shap_values %>%
  mutate(percentage = ifelse(target == "gdh", -percentage, percentage))

# 生成PDF文件
pdf("E:\\Rdoc\\paper_data\\分组1\\gdh_and_glnA_shap_plots_sorted_by_sum.pdf")  # 指定你想保存的PDF文件路径

# 绘制双向条形图
ggplot(shap_values, aes(x = variable, y = percentage, fill = target)) +
  geom_bar(stat = "identity", position = "identity", width = 0.7) +
  coord_flip() +  # 翻转坐标轴
  labs(
    title = "SHAP Value Comparison for Target Variables (Sorted by Total Percentage)",
    x = "Variable",
    y = "SHAP Value"
  ) +
  scale_fill_manual(values = c("gdh" = "#9E7EBD", "glnA" = "#87BFD6")) +  # 设置颜色
  scale_y_continuous(limits = c(-0.4, 0.4), breaks = seq(-0.4, 0.4, 0.2)) +  # 设置 y 轴范围
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.title = element_blank(),  # 去掉图例标题
        legend.position = "top")
# 关闭PDF设备
dev.off()






# 载入必要的包
library(ggplot2)
library(dplyr)

# 读取 SHAP 数据
shap_values_gdh <- read.csv("E:\\Rdoc\\paper_data\\gdh\\variable_importance_percentage.csv")

# 假设你有另一个目标变量的 SHAP 数据：shap_values_glnA
shap_values_glnA <- read.csv("E:\\Rdoc\\paper_data\\glnA\\variable_importance_percentage.csv")

# 合并两个目标变量的 SHAP 数据
shap_values <- bind_rows(
  shap_values_gdh %>% mutate(target = "gdh"),
  shap_values_glnA %>% mutate(target = "glnA")
)

# 绘制双向条形图
ggplot(shap_values, aes(x = reorder(variable, percentage), y = percentage, fill = target)) +
  geom_bar(stat = "identity", position = "dodge") +
  coord_flip() +  # 翻转坐标轴
  labs(
    title = "SHAP Value Comparison for Target Variables",
    x = "Variable",
    y = "SHAP Value"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
