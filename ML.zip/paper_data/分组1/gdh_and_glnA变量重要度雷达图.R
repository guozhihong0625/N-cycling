library(dplyr)
library(fmsb)

# 1. 读取两个数据集
data_gdh <- read.csv("E:/Rdoc/paper_data/gdh/variable_importance_percentage1.csv")
data_glnA <- read.csv("E:/Rdoc/paper_data/glnA/variable_importance_percentage1.csv")

# 2. 统一变量顺序和颜色（确保两个数据集变量一致）
shunxu <- c('Chl_a', 'CODcr', 'COND', 'DO', 'NH3_N', 'NO2_N', 'NO3_N', 
            'ORP', 'pH', 'PO4', 'TDS', 'Temp', 'TN', 'TOC', 'TP')


# 3. 调整数据顺序并转换为宽格式
prepare_data <- function(data) {
  data %>%
    mutate(variable = factor(variable, levels = shunxu)) %>%
    select(variable, percentage) %>%
    tidyr::pivot_wider(names_from = variable, values_from = percentage)
}

radar_gdh <- prepare_data(data_gdh)
radar_glnA <- prepare_data(data_glnA)

# 4. 合并数据并添加最大/最小值行（fmsb要求）
radar_combined <- rbind(
  rep(0.2, ncol(radar_gdh)),  # 最大值
  rep(0, ncol(radar_gdh)),   # 最小值
  radar_gdh,
  radar_glnA
)

# 5. 绘制双网状雷达图
pdf("gdh_glnA变量重要度雷达图.pdf", width = 12, height = 10)
op <- par(mar = c(1, 1, 2, 1))  # 调整边距
par(cex.main = 2.5)  # 调整标题大小
radarchart(
  radar_combined,
  pcol = c("#1F77B4", "#FF9896"),      # 两组数据的线条颜色（红/青）
  pfcol = c(scales::alpha("#1F77B4", 0.3), scales::alpha("#FF9896", 0.3)),  # 填充颜色
  plwd = 5,                            # 线条宽度
  cglcol = "grey",                     # 网格线颜色
  cglty = 1,                           # 网格线类型
  axislabcol = "grey",                 # 轴标签颜色
  vlcex =3,                         # 变量标签大小
  title = "GDH vs GLnA Variable Importance",
  seg = 2                             # 网格分段数
)

# 添加图例
legend(
  "topright",
  legend = c("gdh", "glnA"),
  bty = "n",   # 无边框
  pch = 20,    # 点样式
  col = c("#1F77B4", "#FF9896"),  # 点大小
  pt.cex = 6,
  cex = 3)
dev.off()