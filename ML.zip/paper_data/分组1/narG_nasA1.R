library(dplyr)
library(fmsb)
library(scales)

# 1. 读取数据集
data_nirB <- read.csv("E:/Rdoc/paper_data/nirB/variable_importance_percentage1.csv")

# 2. 统一变量顺序和颜色
shunxu <- c('Chl_a', 'CODcr', 'COND', 'DO', 'NH3_N', 'NO2_N', 'NO3_N', 
            'ORP', 'pH', 'PO4', 'TDS', 'Temp', 'TN', 'TOC', 'TP')

color_palette <- c(
  'Chl_a' = "#4E79A7", 'CODcr' = "#A0CBE8", 'COND' = "#F1CE63", 'DO' = "#FFBE7D", 'NH3_N' = "#F28E2B",
  'NO2_N' = "#B6992D", 'NO3_N' = "#8CD17D", 'ORP' = "#59A14F", 'pH' = "#86BCB6", 'PO4' = "#499894",
  'TDS' = "#D37295", 'Temp' = "#E15759", 'TN' = "#FF9D9A", 'TOC' = "#79706E", 'TP' = "#BAB0AC"
)

# 3. 数据预处理函数
prepare_data <- function(data) {
  data %>%
    mutate(variable = factor(variable, levels = shunxu)) %>%
    select(variable, percentage) %>%
    tidyr::pivot_wider(names_from = variable, values_from = percentage)
}

# 准备数据
radar_nirB <- prepare_data(data_nirB)

# 4. 合并数据并设置坐标范围
radar_combined <- rbind(
  rep(0.2, ncol(radar_nirB)),  # 最大值
  rep(0, ncol(radar_nirB)),    # 最小值
  radar_nirB
)

# 5. 设置颜色（使用ColorBrewer的Set2调色板）
group_color <- "#E15759"
fill_color <- scales::alpha("#E15759", 0.2)

# 6. 绘制雷达图
pdf("nirB变量重要度雷达图.pdf", width = 12, height = 10)
op <- par(mar = c(1, 1, 2, 1))  # 调整边距
par(cex.main = 2.5)  # 调整标题大小
radarchart(
  radar_combined,
  pcol = group_color,          # 线条颜色
  pfcol = fill_color,          # 填充颜色
  plwd = 5,                    # 线条宽度
  plty = 1,                    # 线条类型
  cglcol = "grey",             # 网格线颜色
  cglty = 1,                   # 网格线类型
  axislabcol = "grey",         # 轴标签颜色
  vlcex = 1.5,                 # 变量标签大小
  title = "nirB Variable Importance",
  seg = 2,                     # 网格分段数
  caxislabels = rep("", 4),    # 不显示轴标签
  calcex = 1.1                 # 轴标签大小
)

# 添加图例
legend(
  "topright",
  legend = "nirB",
  bty = "n",
  pch = 20,
  col = group_color,
  pt.cex = 3,
  cex = 2,
  title = "Denitrification Gene"
)

par(op)
dev.off()