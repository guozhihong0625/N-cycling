library(dplyr)
library(fmsb)

# 1. 读取两个数据集
data_narG <- read.csv("E:/Rdoc/paper_data/narG/variable_importance_percentage1.csv")
data_nirB <- read.csv("E:/Rdoc/paper_data/nirB/variable_importance_percentage1.csv")

# 2. 统一变量顺序和颜色（确保两个数据集变量一致）
shunxu <- c('Chl_a', 'CODcr', 'COND', 'DO', 'NH3_N', 'NO2_N', 'NO3_N', 
            'ORP', 'pH', 'PO4', 'TDS', 'Temp', 'TN', 'TOC', 'TP')

#color_palette <- c( 'Chl_a' = "#4E79A7", 'CODcr' = "#A0CBE8", 'COND' = "#F1CE63", 'DO' = "#FFBE7D", 'NH3_N' = "#F28E2B",
#  'NO2_N' = "#B6992D", 'NO3_N' = "#8CD17D", 'ORP' = "#59A14F", 'pH' = "#86BCB6", 'PO4' = "#499894",
#  'TDS' = "#D37295", 'Temp' = "#E15759", 'TN' = "#FF9D9A", 'TOC' = "#79706E", 'TP' = "#BAB0AC"
#)

# 3. 调整数据顺序并转换为宽格式
prepare_data <- function(data) {
  data %>%
    mutate(variable = factor(variable, levels = shunxu)) %>%
    select(variable, percentage) %>%
    tidyr::pivot_wider(names_from = variable, values_from = percentage)
}

radar_narG <- prepare_data(data_narG)
radar_nirB <- prepare_data(data_nirB)

# 4. 合并数据并添加最大/最小值行（fmsb要求）
radar_combined <- rbind(
  rep(0.2, ncol(radar_narG)),  # 最大值
  rep(0, ncol(radar_narG)),   # 最小值
  radar_narG,
  radar_nirB
)

# 5. 绘制双网状雷达图
pdf("narG_nirB变量重要度雷达图.pdf", width = 12, height = 10)
op <- par(mar = c(1, 1, 2, 1))  # 调整边距
par(cex.main = 2.5)  # 调整标题大小
radarchart(
  radar_combined,
  pcol = c("#7CA02C", "#8C564B"),      # 两组数据的线条颜色（红/青）
  pfcol = c(scales::alpha("#7CA02C", 0.3), scales::alpha("#8C564B", 0.3)),  # 填充颜色
  plwd = 5,                            # 线条宽度
  cglcol = "grey",                     # 网格线颜色
  cglty = 1,                           # 网格线类型
  axislabcol = "grey",                 # 轴标签颜色
  vlcex = 3,                         # 变量标签大小
  title = "narG vs nirB Variable Importance",
  seg = 2                              # 网格分段数
)

# 添加图例
legend(
  "topright",
  legend = c("narG", "nirB"),
  bty = "n",   # 无边框
  pch = 20,    # 点样式
  col = c("#7CA02C", "#8C564B"),
  pt.cex = 6,   # 点大小
  cex = 3)

dev.off()