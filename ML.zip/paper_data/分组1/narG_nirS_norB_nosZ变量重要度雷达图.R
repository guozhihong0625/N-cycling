library(dplyr)
library(fmsb)
library(scales)

# 1. 读取四个数据集
data_narG <- read.csv("E:/Rdoc/paper_data/narG/variable_importance_percentage1.csv")
data_nirS <- read.csv("E:/Rdoc/paper_data/nirS/variable_importance_percentage1.csv")
data_norB <- read.csv("E:/Rdoc/paper_data/norB/variable_importance_percentage1.csv")
data_nosZ <- read.csv("E:/Rdoc/paper_data/nosZ/variable_importance_percentage1.csv")

# 2. 统一变量顺序和颜色
shunxu <- c('Chl_a', 'CODcr', 'COND', 'DO', 'NH3_N', 'NO2_N', 'NO3_N', 
            'ORP', 'pH', 'PO4', 'TDS', 'Temp', 'TN', 'TOC', 'TP')


# 3. 数据预处理函数
prepare_data <- function(data) {
  data %>%
    mutate(variable = factor(variable, levels = shunxu)) %>%
    select(variable, percentage) %>%
    tidyr::pivot_wider(names_from = variable, values_from = percentage)
}

# 准备四组数据
radar_narG <- prepare_data(data_narG)
radar_nirS <- prepare_data(data_nirS)
radar_norB <- prepare_data(data_norB)
radar_nosZ <- prepare_data(data_nosZ)

# 4. 合并数据并设置坐标范围
radar_combined <- rbind(
  rep(0.2, ncol(radar_narG)),  # 最大值
  rep(0, ncol(radar_narG)),    # 最小值
  radar_narG,
  radar_nirS,
  radar_norB,
  radar_nosZ
)

# 5. 设置四组颜色（使用ColorBrewer的Set2调色板）
group_colors <- c("#7CA02C", "#0F7F7F", "#BCBD22", "#17BECF")
fill_colors <- c(
  scales::alpha("#7CA02C", 0.3),
  scales::alpha("#0F7F7F", 0.3),
  scales::alpha("#BCBD22", 0.3),
  scales::alpha("#17BECF", 0.3)
)

# 6. 绘制四组雷达图
pdf("narG_nirS_norB_nosZ变量重要度雷达图.pdf", width = 12, height = 10)
op <- par(mar = c(1, 1, 2, 1))  # 调整边距
par(cex.main = 2.5)  # 调整标题大小
radarchart(
  radar_combined,
  pcol = group_colors,          # 四组线条颜色
  pfcol = fill_colors,          # 四组填充颜色
  plwd = 3,                     # 线条宽度
  plty = 1,                     # 线条类型
  cglcol = "grey",              # 网格线颜色
  cglty = 1,                    # 网格线类型
  axislabcol = "grey",          # 轴标签颜色
  vlcex = 3,                  # 变量标签大小
  title = "Denitrification Genes Variable Importance",
  seg = 2,                      # 网格分段数
  caxislabels = paste0(seq(0, 30, by = 10), "%"),  # 轴标签
  calcex = 1.1                  # 轴标签大小
)


# 添加图例
legend(
  "topright",
  legend = c("narG", "nirS", "norB", "nosZ"),
  bty = "n",
  pch = 20,
  col = group_colors,
  pt.cex = 6,
  cex = 3
)

par(op)
dev.off()