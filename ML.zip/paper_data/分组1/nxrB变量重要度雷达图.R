library(dplyr)
library(fmsb)
library(scales)

# 1. 读取数据集
data_nxrB <- read.csv("E:/Rdoc/paper_data/nxrB/variable_importance_percentage1.csv")

# 2. 统一变量顺序和颜色
shunxu <- c('Chl_a', 'CODcr', 'COND', 'DO', 'NH3_N', 'NO2_N', 'NO3_N', 
            'ORP', 'pH', 'PO4', 'TDS', 'Temp', 'TN', 'TOC', 'TP')



# 3. 数据预处理函数
prepare_data <- function(data) {
  data %>%
    mutate(variable = factor(variable, levels = shunxu)) %>%
    select(variable, percentage) %>%
    tidyr::pivot_wider(names_from = variable, values_from = percentage)
}

# 准备数据
radar_nxrB <- prepare_data(data_nxrB)

# 4. 合并数据并设置坐标范围
radar_combined <- rbind(
  rep(0.2, ncol(radar_nxrB)),  # 最大值
  rep(0, ncol(radar_nxrB)),    # 最小值
  radar_nxrB
)

# 5. 设置颜色（使用ColorBrewer的Set2调色板）
group_color <- "#FF7F0E"
fill_color <- scales::alpha("#FF7F0E", 0.2)

# 6. 绘制雷达图
pdf("nxrB变量重要度雷达图.pdf", width = 12, height = 10)
op <- par(mar = c(1, 1, 2, 1))  # 调整边距
par(cex.main = 2.5)  # 调整标题大小

radarchart(
  radar_combined,
  pcol = group_color,          # 线条颜色
  pfcol = fill_color,          # 填充颜色
  plwd = 5,                    # 线条宽度
  plty = 1,                    # 线条类型
  cglcol = "grey",             # 网格线颜色
  cglty = 1,                   # 网格线类型
  axislabcol = "grey",         # 轴标签颜色
  vlcex = 3,                 # 变量标签大小
  title = "nxrB Variable Importance",
  seg = 2,                     # 网格分段数
  caxislabels = rep("", 4),    # 不显示轴标签
  calcex = 1.1                 # 轴标签大小
)

# 添加图例
legend(
  "topright",
  legend = "nxrB",
  bty = "n",
  pch = 20,
  col = group_color,
  pt.cex = 6,
  cex = 3
)

par(op)
dev.off()